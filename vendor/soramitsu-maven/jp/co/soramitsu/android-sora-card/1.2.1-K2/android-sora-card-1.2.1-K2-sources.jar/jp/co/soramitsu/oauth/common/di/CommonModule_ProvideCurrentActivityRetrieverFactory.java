package jp.co.soramitsu.oauth.common.di;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.common.domain.CurrentActivityRetriever;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CommonModule_ProvideCurrentActivityRetrieverFactory implements Factory<CurrentActivityRetriever> {
  private final CommonModule module;

  public CommonModule_ProvideCurrentActivityRetrieverFactory(CommonModule module) {
    this.module = module;
  }

  @Override
  public CurrentActivityRetriever get() {
    return provideCurrentActivityRetriever(module);
  }

  public static CommonModule_ProvideCurrentActivityRetrieverFactory create(CommonModule module) {
    return new CommonModule_ProvideCurrentActivityRetrieverFactory(module);
  }

  public static CurrentActivityRetriever provideCurrentActivityRetriever(CommonModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideCurrentActivityRetriever());
  }
}
