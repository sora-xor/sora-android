package jp.co.soramitsu.oauth.feature.verify.di;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.feature.verify.Timer;

@ScopeMetadata("dagger.hilt.android.scopes.ViewModelScoped")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class VerificationModule_ProvideTimerFactory implements Factory<Timer> {
  private final VerificationModule module;

  public VerificationModule_ProvideTimerFactory(VerificationModule module) {
    this.module = module;
  }

  @Override
  public Timer get() {
    return provideTimer(module);
  }

  public static VerificationModule_ProvideTimerFactory create(VerificationModule module) {
    return new VerificationModule_ProvideTimerFactory(module);
  }

  public static Timer provideTimer(VerificationModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideTimer());
  }
}
