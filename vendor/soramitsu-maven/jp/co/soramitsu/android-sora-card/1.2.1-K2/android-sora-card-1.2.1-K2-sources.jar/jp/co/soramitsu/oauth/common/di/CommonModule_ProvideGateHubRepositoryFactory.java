package jp.co.soramitsu.oauth.common.di;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.sdk.InMemoryRepo;
import jp.co.soramitsu.oauth.feature.AccessTokenValidator;
import jp.co.soramitsu.oauth.feature.gatehub.GateHubRepository;
import jp.co.soramitsu.oauth.network.SoraCardNetworkClient;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CommonModule_ProvideGateHubRepositoryFactory implements Factory<GateHubRepository> {
  private final CommonModule module;

  private final Provider<SoraCardNetworkClient> apiClientProvider;

  private final Provider<AccessTokenValidator> accessTokenValidatorProvider;

  private final Provider<InMemoryRepo> inMemoryRepoProvider;

  public CommonModule_ProvideGateHubRepositoryFactory(CommonModule module,
      Provider<SoraCardNetworkClient> apiClientProvider,
      Provider<AccessTokenValidator> accessTokenValidatorProvider,
      Provider<InMemoryRepo> inMemoryRepoProvider) {
    this.module = module;
    this.apiClientProvider = apiClientProvider;
    this.accessTokenValidatorProvider = accessTokenValidatorProvider;
    this.inMemoryRepoProvider = inMemoryRepoProvider;
  }

  @Override
  public GateHubRepository get() {
    return provideGateHubRepository(module, apiClientProvider.get(), accessTokenValidatorProvider.get(), inMemoryRepoProvider.get());
  }

  public static CommonModule_ProvideGateHubRepositoryFactory create(CommonModule module,
      javax.inject.Provider<SoraCardNetworkClient> apiClientProvider,
      javax.inject.Provider<AccessTokenValidator> accessTokenValidatorProvider,
      javax.inject.Provider<InMemoryRepo> inMemoryRepoProvider) {
    return new CommonModule_ProvideGateHubRepositoryFactory(module, Providers.asDaggerProvider(apiClientProvider), Providers.asDaggerProvider(accessTokenValidatorProvider), Providers.asDaggerProvider(inMemoryRepoProvider));
  }

  public static CommonModule_ProvideGateHubRepositoryFactory create(CommonModule module,
      Provider<SoraCardNetworkClient> apiClientProvider,
      Provider<AccessTokenValidator> accessTokenValidatorProvider,
      Provider<InMemoryRepo> inMemoryRepoProvider) {
    return new CommonModule_ProvideGateHubRepositoryFactory(module, apiClientProvider, accessTokenValidatorProvider, inMemoryRepoProvider);
  }

  public static GateHubRepository provideGateHubRepository(CommonModule instance,
      SoraCardNetworkClient apiClient, AccessTokenValidator accessTokenValidator,
      InMemoryRepo inMemoryRepo) {
    return Preconditions.checkNotNullFromProvides(instance.provideGateHubRepository(apiClient, accessTokenValidator, inMemoryRepo));
  }
}
