package jp.co.soramitsu.oauth.feature.gatehub.onboarding;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata("dagger.hilt.android.internal.lifecycle.HiltViewModelMap.KeySet")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class GatehubOnboardingProgressViewModel_HiltModules_KeyModule_ProvideFactory implements Factory<Boolean> {
  @Override
  public Boolean get() {
    return provide();
  }

  public static GatehubOnboardingProgressViewModel_HiltModules_KeyModule_ProvideFactory create() {
    return InstanceHolder.INSTANCE;
  }

  public static boolean provide() {
    return GatehubOnboardingProgressViewModel_HiltModules.KeyModule.provide();
  }

  private static final class InstanceHolder {
    static final GatehubOnboardingProgressViewModel_HiltModules_KeyModule_ProvideFactory INSTANCE = new GatehubOnboardingProgressViewModel_HiltModules_KeyModule_ProvideFactory();
  }
}
