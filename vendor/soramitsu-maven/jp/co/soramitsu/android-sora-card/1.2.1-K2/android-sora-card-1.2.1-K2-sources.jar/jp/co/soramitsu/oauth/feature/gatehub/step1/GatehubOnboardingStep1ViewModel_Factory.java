package jp.co.soramitsu.oauth.feature.gatehub.step1;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;
import jp.co.soramitsu.oauth.base.sdk.InMemoryRepo;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class GatehubOnboardingStep1ViewModel_Factory implements Factory<GatehubOnboardingStep1ViewModel> {
  private final Provider<MainRouter> mainRouterProvider;

  private final Provider<InMemoryRepo> inMemoryRepoProvider;

  public GatehubOnboardingStep1ViewModel_Factory(Provider<MainRouter> mainRouterProvider,
      Provider<InMemoryRepo> inMemoryRepoProvider) {
    this.mainRouterProvider = mainRouterProvider;
    this.inMemoryRepoProvider = inMemoryRepoProvider;
  }

  @Override
  public GatehubOnboardingStep1ViewModel get() {
    return newInstance(mainRouterProvider.get(), inMemoryRepoProvider.get());
  }

  public static GatehubOnboardingStep1ViewModel_Factory create(
      javax.inject.Provider<MainRouter> mainRouterProvider,
      javax.inject.Provider<InMemoryRepo> inMemoryRepoProvider) {
    return new GatehubOnboardingStep1ViewModel_Factory(Providers.asDaggerProvider(mainRouterProvider), Providers.asDaggerProvider(inMemoryRepoProvider));
  }

  public static GatehubOnboardingStep1ViewModel_Factory create(
      Provider<MainRouter> mainRouterProvider, Provider<InMemoryRepo> inMemoryRepoProvider) {
    return new GatehubOnboardingStep1ViewModel_Factory(mainRouterProvider, inMemoryRepoProvider);
  }

  public static GatehubOnboardingStep1ViewModel newInstance(MainRouter mainRouter,
      InMemoryRepo inMemoryRepo) {
    return new GatehubOnboardingStep1ViewModel(mainRouter, inMemoryRepo);
  }
}
