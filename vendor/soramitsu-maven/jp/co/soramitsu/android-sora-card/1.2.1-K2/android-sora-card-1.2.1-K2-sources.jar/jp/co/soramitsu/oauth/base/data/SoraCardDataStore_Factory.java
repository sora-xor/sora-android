package jp.co.soramitsu.oauth.base.data;

import android.content.Context;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("dagger.hilt.android.qualifiers.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class SoraCardDataStore_Factory implements Factory<SoraCardDataStore> {
  private final Provider<Context> contextProvider;

  public SoraCardDataStore_Factory(Provider<Context> contextProvider) {
    this.contextProvider = contextProvider;
  }

  @Override
  public SoraCardDataStore get() {
    return newInstance(contextProvider.get());
  }

  public static SoraCardDataStore_Factory create(javax.inject.Provider<Context> contextProvider) {
    return new SoraCardDataStore_Factory(Providers.asDaggerProvider(contextProvider));
  }

  public static SoraCardDataStore_Factory create(Provider<Context> contextProvider) {
    return new SoraCardDataStore_Factory(contextProvider);
  }

  public static SoraCardDataStore newInstance(Context context) {
    return new SoraCardDataStore(context);
  }
}
