package jp.co.soramitsu.oauth.feature.verify.email;

import dagger.internal.DaggerGenerated;
import dagger.internal.IdentifierNameString;
import dagger.internal.KeepFieldType;
import javax.annotation.processing.Generated;

@IdentifierNameString
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class EnterEmailViewModel_HiltModules_KeyModule_Provide_LazyMapKey {
  @KeepFieldType
  static EnterEmailViewModel keepFieldType;

  public static String lazyClassKeyName = "jp.co.soramitsu.oauth.feature.verify.email.EnterEmailViewModel";
}
