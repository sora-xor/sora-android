package jp.co.soramitsu.oauth.feature.verify.email;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;
import jp.co.soramitsu.oauth.common.domain.PWOAuthClientProxy;
import jp.co.soramitsu.oauth.feature.session.domain.UserSessionRepository;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class EnterEmailViewModel_Factory implements Factory<EnterEmailViewModel> {
  private final Provider<MainRouter> mainRouterProvider;

  private final Provider<UserSessionRepository> userSessionRepositoryProvider;

  private final Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider;

  public EnterEmailViewModel_Factory(Provider<MainRouter> mainRouterProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    this.mainRouterProvider = mainRouterProvider;
    this.userSessionRepositoryProvider = userSessionRepositoryProvider;
    this.pwoAuthClientProxyProvider = pwoAuthClientProxyProvider;
  }

  @Override
  public EnterEmailViewModel get() {
    return newInstance(mainRouterProvider.get(), userSessionRepositoryProvider.get(), pwoAuthClientProxyProvider.get());
  }

  public static EnterEmailViewModel_Factory create(
      javax.inject.Provider<MainRouter> mainRouterProvider,
      javax.inject.Provider<UserSessionRepository> userSessionRepositoryProvider,
      javax.inject.Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    return new EnterEmailViewModel_Factory(Providers.asDaggerProvider(mainRouterProvider), Providers.asDaggerProvider(userSessionRepositoryProvider), Providers.asDaggerProvider(pwoAuthClientProxyProvider));
  }

  public static EnterEmailViewModel_Factory create(Provider<MainRouter> mainRouterProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    return new EnterEmailViewModel_Factory(mainRouterProvider, userSessionRepositoryProvider, pwoAuthClientProxyProvider);
  }

  public static EnterEmailViewModel newInstance(MainRouter mainRouter,
      UserSessionRepository userSessionRepository, PWOAuthClientProxy pwoAuthClientProxy) {
    return new EnterEmailViewModel(mainRouter, userSessionRepository, pwoAuthClientProxy);
  }
}
