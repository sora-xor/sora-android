package jp.co.soramitsu.oauth.base.navigation;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class NavigationModule_ProvideMainRouterFactory implements Factory<MainRouter> {
  private final NavigationModule module;

  public NavigationModule_ProvideMainRouterFactory(NavigationModule module) {
    this.module = module;
  }

  @Override
  public MainRouter get() {
    return provideMainRouter(module);
  }

  public static NavigationModule_ProvideMainRouterFactory create(NavigationModule module) {
    return new NavigationModule_ProvideMainRouterFactory(module);
  }

  public static MainRouter provideMainRouter(NavigationModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideMainRouter());
  }
}
