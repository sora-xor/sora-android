package jp.co.soramitsu.oauth.feature.verify.phone;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;
import jp.co.soramitsu.oauth.base.sdk.InMemoryRepo;
import jp.co.soramitsu.oauth.common.domain.PWOAuthClientProxy;
import jp.co.soramitsu.oauth.feature.verify.Timer;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class VerifyPhoneNumberViewModel_Factory implements Factory<VerifyPhoneNumberViewModel> {
  private final Provider<MainRouter> mainRouterProvider;

  private final Provider<Timer> timerProvider;

  private final Provider<InMemoryRepo> inMemoryRepoProvider;

  private final Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider;

  public VerifyPhoneNumberViewModel_Factory(Provider<MainRouter> mainRouterProvider,
      Provider<Timer> timerProvider, Provider<InMemoryRepo> inMemoryRepoProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    this.mainRouterProvider = mainRouterProvider;
    this.timerProvider = timerProvider;
    this.inMemoryRepoProvider = inMemoryRepoProvider;
    this.pwoAuthClientProxyProvider = pwoAuthClientProxyProvider;
  }

  @Override
  public VerifyPhoneNumberViewModel get() {
    return newInstance(mainRouterProvider.get(), timerProvider.get(), inMemoryRepoProvider.get(), pwoAuthClientProxyProvider.get());
  }

  public static VerifyPhoneNumberViewModel_Factory create(
      javax.inject.Provider<MainRouter> mainRouterProvider,
      javax.inject.Provider<Timer> timerProvider,
      javax.inject.Provider<InMemoryRepo> inMemoryRepoProvider,
      javax.inject.Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    return new VerifyPhoneNumberViewModel_Factory(Providers.asDaggerProvider(mainRouterProvider), Providers.asDaggerProvider(timerProvider), Providers.asDaggerProvider(inMemoryRepoProvider), Providers.asDaggerProvider(pwoAuthClientProxyProvider));
  }

  public static VerifyPhoneNumberViewModel_Factory create(Provider<MainRouter> mainRouterProvider,
      Provider<Timer> timerProvider, Provider<InMemoryRepo> inMemoryRepoProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    return new VerifyPhoneNumberViewModel_Factory(mainRouterProvider, timerProvider, inMemoryRepoProvider, pwoAuthClientProxyProvider);
  }

  public static VerifyPhoneNumberViewModel newInstance(MainRouter mainRouter, Timer timer,
      InMemoryRepo inMemoryRepo, PWOAuthClientProxy pwoAuthClientProxy) {
    return new VerifyPhoneNumberViewModel(mainRouter, timer, inMemoryRepo, pwoAuthClientProxy);
  }
}
