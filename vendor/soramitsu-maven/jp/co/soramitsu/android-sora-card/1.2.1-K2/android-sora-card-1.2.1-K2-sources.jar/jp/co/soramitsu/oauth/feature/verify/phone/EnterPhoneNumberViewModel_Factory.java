package jp.co.soramitsu.oauth.feature.verify.phone;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;
import jp.co.soramitsu.oauth.base.navigation.SetActivityResult;
import jp.co.soramitsu.oauth.base.sdk.InMemoryRepo;
import jp.co.soramitsu.oauth.common.domain.KycRepository;
import jp.co.soramitsu.oauth.common.domain.PWOAuthClientProxy;
import jp.co.soramitsu.oauth.feature.session.domain.UserSessionRepository;
import jp.co.soramitsu.oauth.feature.telephone.LocaleService;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class EnterPhoneNumberViewModel_Factory implements Factory<EnterPhoneNumberViewModel> {
  private final Provider<MainRouter> mainRouterProvider;

  private final Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider;

  private final Provider<LocaleService> localeServiceProvider;

  private final Provider<KycRepository> kycRepositoryProvider;

  private final Provider<SetActivityResult> setActivityResultProvider;

  private final Provider<InMemoryRepo> inMemoryRepoProvider;

  private final Provider<UserSessionRepository> userSessionRepositoryProvider;

  public EnterPhoneNumberViewModel_Factory(Provider<MainRouter> mainRouterProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider,
      Provider<LocaleService> localeServiceProvider, Provider<KycRepository> kycRepositoryProvider,
      Provider<SetActivityResult> setActivityResultProvider,
      Provider<InMemoryRepo> inMemoryRepoProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider) {
    this.mainRouterProvider = mainRouterProvider;
    this.pwoAuthClientProxyProvider = pwoAuthClientProxyProvider;
    this.localeServiceProvider = localeServiceProvider;
    this.kycRepositoryProvider = kycRepositoryProvider;
    this.setActivityResultProvider = setActivityResultProvider;
    this.inMemoryRepoProvider = inMemoryRepoProvider;
    this.userSessionRepositoryProvider = userSessionRepositoryProvider;
  }

  @Override
  public EnterPhoneNumberViewModel get() {
    return newInstance(mainRouterProvider.get(), pwoAuthClientProxyProvider.get(), localeServiceProvider.get(), kycRepositoryProvider.get(), setActivityResultProvider.get(), inMemoryRepoProvider.get(), userSessionRepositoryProvider.get());
  }

  public static EnterPhoneNumberViewModel_Factory create(
      javax.inject.Provider<MainRouter> mainRouterProvider,
      javax.inject.Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider,
      javax.inject.Provider<LocaleService> localeServiceProvider,
      javax.inject.Provider<KycRepository> kycRepositoryProvider,
      javax.inject.Provider<SetActivityResult> setActivityResultProvider,
      javax.inject.Provider<InMemoryRepo> inMemoryRepoProvider,
      javax.inject.Provider<UserSessionRepository> userSessionRepositoryProvider) {
    return new EnterPhoneNumberViewModel_Factory(Providers.asDaggerProvider(mainRouterProvider), Providers.asDaggerProvider(pwoAuthClientProxyProvider), Providers.asDaggerProvider(localeServiceProvider), Providers.asDaggerProvider(kycRepositoryProvider), Providers.asDaggerProvider(setActivityResultProvider), Providers.asDaggerProvider(inMemoryRepoProvider), Providers.asDaggerProvider(userSessionRepositoryProvider));
  }

  public static EnterPhoneNumberViewModel_Factory create(Provider<MainRouter> mainRouterProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider,
      Provider<LocaleService> localeServiceProvider, Provider<KycRepository> kycRepositoryProvider,
      Provider<SetActivityResult> setActivityResultProvider,
      Provider<InMemoryRepo> inMemoryRepoProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider) {
    return new EnterPhoneNumberViewModel_Factory(mainRouterProvider, pwoAuthClientProxyProvider, localeServiceProvider, kycRepositoryProvider, setActivityResultProvider, inMemoryRepoProvider, userSessionRepositoryProvider);
  }

  public static EnterPhoneNumberViewModel newInstance(MainRouter mainRouter,
      PWOAuthClientProxy pwoAuthClientProxy, LocaleService localeService,
      KycRepository kycRepository, SetActivityResult setActivityResult, InMemoryRepo inMemoryRepo,
      UserSessionRepository userSessionRepository) {
    return new EnterPhoneNumberViewModel(mainRouter, pwoAuthClientProxy, localeService, kycRepository, setActivityResult, inMemoryRepo, userSessionRepository);
  }
}
