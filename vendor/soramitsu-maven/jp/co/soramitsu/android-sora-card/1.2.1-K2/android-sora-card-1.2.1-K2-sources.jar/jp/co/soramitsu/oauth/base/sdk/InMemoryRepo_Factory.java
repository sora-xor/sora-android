package jp.co.soramitsu.oauth.base.sdk;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class InMemoryRepo_Factory implements Factory<InMemoryRepo> {
  @Override
  public InMemoryRepo get() {
    return newInstance();
  }

  public static InMemoryRepo_Factory create() {
    return InstanceHolder.INSTANCE;
  }

  public static InMemoryRepo newInstance() {
    return new InMemoryRepo();
  }

  private static final class InstanceHolder {
    static final InMemoryRepo_Factory INSTANCE = new InMemoryRepo_Factory();
  }
}
