package jp.co.soramitsu.oauth.common.di;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.common.domain.PWOAuthClientProxy;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CommonModule_ProvidePWOAuthClientProxyFactory implements Factory<PWOAuthClientProxy> {
  private final CommonModule module;

  public CommonModule_ProvidePWOAuthClientProxyFactory(CommonModule module) {
    this.module = module;
  }

  @Override
  public PWOAuthClientProxy get() {
    return providePWOAuthClientProxy(module);
  }

  public static CommonModule_ProvidePWOAuthClientProxyFactory create(CommonModule module) {
    return new CommonModule_ProvidePWOAuthClientProxyFactory(module);
  }

  public static PWOAuthClientProxy providePWOAuthClientProxy(CommonModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.providePWOAuthClientProxy());
  }
}
