package jp.co.soramitsu.oauth.feature.kyc.result;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;
import jp.co.soramitsu.oauth.base.navigation.SetActivityResult;
import jp.co.soramitsu.oauth.common.domain.PWOAuthClientProxy;
import jp.co.soramitsu.oauth.feature.session.domain.UserSessionRepository;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class VerificationInProgressViewModel_Factory implements Factory<VerificationInProgressViewModel> {
  private final Provider<MainRouter> mainRouterProvider;

  private final Provider<SetActivityResult> setActivityResultProvider;

  private final Provider<UserSessionRepository> userSessionRepositoryProvider;

  private final Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider;

  public VerificationInProgressViewModel_Factory(Provider<MainRouter> mainRouterProvider,
      Provider<SetActivityResult> setActivityResultProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    this.mainRouterProvider = mainRouterProvider;
    this.setActivityResultProvider = setActivityResultProvider;
    this.userSessionRepositoryProvider = userSessionRepositoryProvider;
    this.pwoAuthClientProxyProvider = pwoAuthClientProxyProvider;
  }

  @Override
  public VerificationInProgressViewModel get() {
    return newInstance(mainRouterProvider.get(), setActivityResultProvider.get(), userSessionRepositoryProvider.get(), pwoAuthClientProxyProvider.get());
  }

  public static VerificationInProgressViewModel_Factory create(
      javax.inject.Provider<MainRouter> mainRouterProvider,
      javax.inject.Provider<SetActivityResult> setActivityResultProvider,
      javax.inject.Provider<UserSessionRepository> userSessionRepositoryProvider,
      javax.inject.Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    return new VerificationInProgressViewModel_Factory(Providers.asDaggerProvider(mainRouterProvider), Providers.asDaggerProvider(setActivityResultProvider), Providers.asDaggerProvider(userSessionRepositoryProvider), Providers.asDaggerProvider(pwoAuthClientProxyProvider));
  }

  public static VerificationInProgressViewModel_Factory create(
      Provider<MainRouter> mainRouterProvider,
      Provider<SetActivityResult> setActivityResultProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    return new VerificationInProgressViewModel_Factory(mainRouterProvider, setActivityResultProvider, userSessionRepositoryProvider, pwoAuthClientProxyProvider);
  }

  public static VerificationInProgressViewModel newInstance(MainRouter mainRouter,
      SetActivityResult setActivityResult, UserSessionRepository userSessionRepository,
      PWOAuthClientProxy pwoAuthClientProxy) {
    return new VerificationInProgressViewModel(mainRouter, setActivityResult, userSessionRepository, pwoAuthClientProxy);
  }
}
