package jp.co.soramitsu.oauth.feature.verify.phone;

import androidx.lifecycle.SavedStateHandle;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;
import jp.co.soramitsu.oauth.common.domain.KycRepository;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CountryListViewModel_Factory implements Factory<CountryListViewModel> {
  private final Provider<SavedStateHandle> savedStateHandleProvider;

  private final Provider<KycRepository> kycRepositoryProvider;

  private final Provider<MainRouter> mainRouterProvider;

  public CountryListViewModel_Factory(Provider<SavedStateHandle> savedStateHandleProvider,
      Provider<KycRepository> kycRepositoryProvider, Provider<MainRouter> mainRouterProvider) {
    this.savedStateHandleProvider = savedStateHandleProvider;
    this.kycRepositoryProvider = kycRepositoryProvider;
    this.mainRouterProvider = mainRouterProvider;
  }

  @Override
  public CountryListViewModel get() {
    return newInstance(savedStateHandleProvider.get(), kycRepositoryProvider.get(), mainRouterProvider.get());
  }

  public static CountryListViewModel_Factory create(
      javax.inject.Provider<SavedStateHandle> savedStateHandleProvider,
      javax.inject.Provider<KycRepository> kycRepositoryProvider,
      javax.inject.Provider<MainRouter> mainRouterProvider) {
    return new CountryListViewModel_Factory(Providers.asDaggerProvider(savedStateHandleProvider), Providers.asDaggerProvider(kycRepositoryProvider), Providers.asDaggerProvider(mainRouterProvider));
  }

  public static CountryListViewModel_Factory create(
      Provider<SavedStateHandle> savedStateHandleProvider,
      Provider<KycRepository> kycRepositoryProvider, Provider<MainRouter> mainRouterProvider) {
    return new CountryListViewModel_Factory(savedStateHandleProvider, kycRepositoryProvider, mainRouterProvider);
  }

  public static CountryListViewModel newInstance(SavedStateHandle savedStateHandle,
      KycRepository kycRepository, MainRouter mainRouter) {
    return new CountryListViewModel(savedStateHandle, kycRepository, mainRouter);
  }
}
