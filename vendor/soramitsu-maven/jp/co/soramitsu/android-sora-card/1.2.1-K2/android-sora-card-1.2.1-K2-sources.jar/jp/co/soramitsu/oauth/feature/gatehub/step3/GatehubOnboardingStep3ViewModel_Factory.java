package jp.co.soramitsu.oauth.feature.gatehub.step3;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;
import jp.co.soramitsu.oauth.base.sdk.InMemoryRepo;
import jp.co.soramitsu.oauth.feature.gatehub.GateHubRepository;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class GatehubOnboardingStep3ViewModel_Factory implements Factory<GatehubOnboardingStep3ViewModel> {
  private final Provider<MainRouter> mainRouterProvider;

  private final Provider<InMemoryRepo> inMemoryRepoProvider;

  private final Provider<GateHubRepository> gateHubRepositoryProvider;

  public GatehubOnboardingStep3ViewModel_Factory(Provider<MainRouter> mainRouterProvider,
      Provider<InMemoryRepo> inMemoryRepoProvider,
      Provider<GateHubRepository> gateHubRepositoryProvider) {
    this.mainRouterProvider = mainRouterProvider;
    this.inMemoryRepoProvider = inMemoryRepoProvider;
    this.gateHubRepositoryProvider = gateHubRepositoryProvider;
  }

  @Override
  public GatehubOnboardingStep3ViewModel get() {
    return newInstance(mainRouterProvider.get(), inMemoryRepoProvider.get(), gateHubRepositoryProvider.get());
  }

  public static GatehubOnboardingStep3ViewModel_Factory create(
      javax.inject.Provider<MainRouter> mainRouterProvider,
      javax.inject.Provider<InMemoryRepo> inMemoryRepoProvider,
      javax.inject.Provider<GateHubRepository> gateHubRepositoryProvider) {
    return new GatehubOnboardingStep3ViewModel_Factory(Providers.asDaggerProvider(mainRouterProvider), Providers.asDaggerProvider(inMemoryRepoProvider), Providers.asDaggerProvider(gateHubRepositoryProvider));
  }

  public static GatehubOnboardingStep3ViewModel_Factory create(
      Provider<MainRouter> mainRouterProvider, Provider<InMemoryRepo> inMemoryRepoProvider,
      Provider<GateHubRepository> gateHubRepositoryProvider) {
    return new GatehubOnboardingStep3ViewModel_Factory(mainRouterProvider, inMemoryRepoProvider, gateHubRepositoryProvider);
  }

  public static GatehubOnboardingStep3ViewModel newInstance(MainRouter mainRouter,
      InMemoryRepo inMemoryRepo, GateHubRepository gateHubRepository) {
    return new GatehubOnboardingStep3ViewModel(mainRouter, inMemoryRepo, gateHubRepository);
  }
}
