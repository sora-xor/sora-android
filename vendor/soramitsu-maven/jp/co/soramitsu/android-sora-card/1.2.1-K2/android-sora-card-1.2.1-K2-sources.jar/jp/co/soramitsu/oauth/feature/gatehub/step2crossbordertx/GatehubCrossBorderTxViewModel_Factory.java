package jp.co.soramitsu.oauth.feature.gatehub.step2crossbordertx;

import androidx.lifecycle.SavedStateHandle;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;
import jp.co.soramitsu.oauth.base.sdk.InMemoryRepo;
import jp.co.soramitsu.oauth.common.domain.KycRepository;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class GatehubCrossBorderTxViewModel_Factory implements Factory<GatehubCrossBorderTxViewModel> {
  private final Provider<SavedStateHandle> savedStateHandleProvider;

  private final Provider<MainRouter> mainRouterProvider;

  private final Provider<InMemoryRepo> inMemoryRepoProvider;

  private final Provider<KycRepository> kycRepositoryProvider;

  public GatehubCrossBorderTxViewModel_Factory(Provider<SavedStateHandle> savedStateHandleProvider,
      Provider<MainRouter> mainRouterProvider, Provider<InMemoryRepo> inMemoryRepoProvider,
      Provider<KycRepository> kycRepositoryProvider) {
    this.savedStateHandleProvider = savedStateHandleProvider;
    this.mainRouterProvider = mainRouterProvider;
    this.inMemoryRepoProvider = inMemoryRepoProvider;
    this.kycRepositoryProvider = kycRepositoryProvider;
  }

  @Override
  public GatehubCrossBorderTxViewModel get() {
    return newInstance(savedStateHandleProvider.get(), mainRouterProvider.get(), inMemoryRepoProvider.get(), kycRepositoryProvider.get());
  }

  public static GatehubCrossBorderTxViewModel_Factory create(
      javax.inject.Provider<SavedStateHandle> savedStateHandleProvider,
      javax.inject.Provider<MainRouter> mainRouterProvider,
      javax.inject.Provider<InMemoryRepo> inMemoryRepoProvider,
      javax.inject.Provider<KycRepository> kycRepositoryProvider) {
    return new GatehubCrossBorderTxViewModel_Factory(Providers.asDaggerProvider(savedStateHandleProvider), Providers.asDaggerProvider(mainRouterProvider), Providers.asDaggerProvider(inMemoryRepoProvider), Providers.asDaggerProvider(kycRepositoryProvider));
  }

  public static GatehubCrossBorderTxViewModel_Factory create(
      Provider<SavedStateHandle> savedStateHandleProvider, Provider<MainRouter> mainRouterProvider,
      Provider<InMemoryRepo> inMemoryRepoProvider, Provider<KycRepository> kycRepositoryProvider) {
    return new GatehubCrossBorderTxViewModel_Factory(savedStateHandleProvider, mainRouterProvider, inMemoryRepoProvider, kycRepositoryProvider);
  }

  public static GatehubCrossBorderTxViewModel newInstance(SavedStateHandle savedStateHandle,
      MainRouter mainRouter, InMemoryRepo inMemoryRepo, KycRepository kycRepository) {
    return new GatehubCrossBorderTxViewModel(savedStateHandle, mainRouter, inMemoryRepo, kycRepository);
  }
}
