package jp.co.soramitsu.oauth.base.uiscreens;

import dagger.MembersInjector;
import dagger.internal.DaggerGenerated;
import dagger.internal.InjectedFieldSignature;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;
import jp.co.soramitsu.oauth.common.domain.CurrentActivityRetriever;
import jp.co.soramitsu.oauth.common.domain.PWOAuthClientProxy;

@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CardActivity_MembersInjector implements MembersInjector<CardActivity> {
  private final Provider<CurrentActivityRetriever> currentActivityRetrieverProvider;

  private final Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider;

  private final Provider<MainRouter> mainRouterProvider;

  public CardActivity_MembersInjector(
      Provider<CurrentActivityRetriever> currentActivityRetrieverProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider,
      Provider<MainRouter> mainRouterProvider) {
    this.currentActivityRetrieverProvider = currentActivityRetrieverProvider;
    this.pwoAuthClientProxyProvider = pwoAuthClientProxyProvider;
    this.mainRouterProvider = mainRouterProvider;
  }

  public static MembersInjector<CardActivity> create(
      Provider<CurrentActivityRetriever> currentActivityRetrieverProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider,
      Provider<MainRouter> mainRouterProvider) {
    return new CardActivity_MembersInjector(currentActivityRetrieverProvider, pwoAuthClientProxyProvider, mainRouterProvider);
  }

  public static MembersInjector<CardActivity> create(
      javax.inject.Provider<CurrentActivityRetriever> currentActivityRetrieverProvider,
      javax.inject.Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider,
      javax.inject.Provider<MainRouter> mainRouterProvider) {
    return new CardActivity_MembersInjector(Providers.asDaggerProvider(currentActivityRetrieverProvider), Providers.asDaggerProvider(pwoAuthClientProxyProvider), Providers.asDaggerProvider(mainRouterProvider));
  }

  @Override
  public void injectMembers(CardActivity instance) {
    injectCurrentActivityRetriever(instance, currentActivityRetrieverProvider.get());
    injectPwoAuthClientProxy(instance, pwoAuthClientProxyProvider.get());
    injectMainRouter(instance, mainRouterProvider.get());
  }

  @InjectedFieldSignature("jp.co.soramitsu.oauth.base.uiscreens.CardActivity.currentActivityRetriever")
  public static void injectCurrentActivityRetriever(CardActivity instance,
      CurrentActivityRetriever currentActivityRetriever) {
    instance.currentActivityRetriever = currentActivityRetriever;
  }

  @InjectedFieldSignature("jp.co.soramitsu.oauth.base.uiscreens.CardActivity.pwoAuthClientProxy")
  public static void injectPwoAuthClientProxy(CardActivity instance,
      PWOAuthClientProxy pwoAuthClientProxy) {
    instance.pwoAuthClientProxy = pwoAuthClientProxy;
  }

  @InjectedFieldSignature("jp.co.soramitsu.oauth.base.uiscreens.CardActivity.mainRouter")
  public static void injectMainRouter(CardActivity instance, MainRouter mainRouter) {
    instance.mainRouter = mainRouter;
  }
}
