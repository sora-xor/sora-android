package jp.co.soramitsu.oauth.feature.usernotfound;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;
import jp.co.soramitsu.oauth.base.sdk.InMemoryRepo;
import jp.co.soramitsu.oauth.feature.session.domain.UserSessionRepository;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class UserNotFoundViewModel_Factory implements Factory<UserNotFoundViewModel> {
  private final Provider<MainRouter> mainRouterProvider;

  private final Provider<InMemoryRepo> inMemoryRepoProvider;

  private final Provider<UserSessionRepository> userSessionRepositoryProvider;

  public UserNotFoundViewModel_Factory(Provider<MainRouter> mainRouterProvider,
      Provider<InMemoryRepo> inMemoryRepoProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider) {
    this.mainRouterProvider = mainRouterProvider;
    this.inMemoryRepoProvider = inMemoryRepoProvider;
    this.userSessionRepositoryProvider = userSessionRepositoryProvider;
  }

  @Override
  public UserNotFoundViewModel get() {
    return newInstance(mainRouterProvider.get(), inMemoryRepoProvider.get(), userSessionRepositoryProvider.get());
  }

  public static UserNotFoundViewModel_Factory create(
      javax.inject.Provider<MainRouter> mainRouterProvider,
      javax.inject.Provider<InMemoryRepo> inMemoryRepoProvider,
      javax.inject.Provider<UserSessionRepository> userSessionRepositoryProvider) {
    return new UserNotFoundViewModel_Factory(Providers.asDaggerProvider(mainRouterProvider), Providers.asDaggerProvider(inMemoryRepoProvider), Providers.asDaggerProvider(userSessionRepositoryProvider));
  }

  public static UserNotFoundViewModel_Factory create(Provider<MainRouter> mainRouterProvider,
      Provider<InMemoryRepo> inMemoryRepoProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider) {
    return new UserNotFoundViewModel_Factory(mainRouterProvider, inMemoryRepoProvider, userSessionRepositoryProvider);
  }

  public static UserNotFoundViewModel newInstance(MainRouter mainRouter, InMemoryRepo inMemoryRepo,
      UserSessionRepository userSessionRepository) {
    return new UserNotFoundViewModel(mainRouter, inMemoryRepo, userSessionRepository);
  }
}
