package jp.co.soramitsu.oauth.feature.verify.email;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;
import jp.co.soramitsu.oauth.common.domain.PWOAuthClientProxy;
import jp.co.soramitsu.oauth.feature.session.domain.UserSessionRepository;
import jp.co.soramitsu.oauth.feature.verify.Timer;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class VerifyEmailViewModel_Factory implements Factory<VerifyEmailViewModel> {
  private final Provider<MainRouter> mainRouterProvider;

  private final Provider<UserSessionRepository> userSessionRepositoryProvider;

  private final Provider<Timer> timerProvider;

  private final Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider;

  public VerifyEmailViewModel_Factory(Provider<MainRouter> mainRouterProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider, Provider<Timer> timerProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    this.mainRouterProvider = mainRouterProvider;
    this.userSessionRepositoryProvider = userSessionRepositoryProvider;
    this.timerProvider = timerProvider;
    this.pwoAuthClientProxyProvider = pwoAuthClientProxyProvider;
  }

  @Override
  public VerifyEmailViewModel get() {
    return newInstance(mainRouterProvider.get(), userSessionRepositoryProvider.get(), timerProvider.get(), pwoAuthClientProxyProvider.get());
  }

  public static VerifyEmailViewModel_Factory create(
      javax.inject.Provider<MainRouter> mainRouterProvider,
      javax.inject.Provider<UserSessionRepository> userSessionRepositoryProvider,
      javax.inject.Provider<Timer> timerProvider,
      javax.inject.Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    return new VerifyEmailViewModel_Factory(Providers.asDaggerProvider(mainRouterProvider), Providers.asDaggerProvider(userSessionRepositoryProvider), Providers.asDaggerProvider(timerProvider), Providers.asDaggerProvider(pwoAuthClientProxyProvider));
  }

  public static VerifyEmailViewModel_Factory create(Provider<MainRouter> mainRouterProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider, Provider<Timer> timerProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    return new VerifyEmailViewModel_Factory(mainRouterProvider, userSessionRepositoryProvider, timerProvider, pwoAuthClientProxyProvider);
  }

  public static VerifyEmailViewModel newInstance(MainRouter mainRouter,
      UserSessionRepository userSessionRepository, Timer timer,
      PWOAuthClientProxy pwoAuthClientProxy) {
    return new VerifyEmailViewModel(mainRouter, userSessionRepository, timer, pwoAuthClientProxy);
  }
}
