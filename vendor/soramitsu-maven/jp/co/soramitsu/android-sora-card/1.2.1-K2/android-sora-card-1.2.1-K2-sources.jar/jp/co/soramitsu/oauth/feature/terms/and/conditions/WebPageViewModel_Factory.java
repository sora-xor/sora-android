package jp.co.soramitsu.oauth.feature.terms.and.conditions;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;
import jp.co.soramitsu.oauth.base.navigation.SetActivityResult;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class WebPageViewModel_Factory implements Factory<WebPageViewModel> {
  private final Provider<MainRouter> mainRouterProvider;

  private final Provider<SetActivityResult> setActivityResultProvider;

  public WebPageViewModel_Factory(Provider<MainRouter> mainRouterProvider,
      Provider<SetActivityResult> setActivityResultProvider) {
    this.mainRouterProvider = mainRouterProvider;
    this.setActivityResultProvider = setActivityResultProvider;
  }

  @Override
  public WebPageViewModel get() {
    return newInstance(mainRouterProvider.get(), setActivityResultProvider.get());
  }

  public static WebPageViewModel_Factory create(
      javax.inject.Provider<MainRouter> mainRouterProvider,
      javax.inject.Provider<SetActivityResult> setActivityResultProvider) {
    return new WebPageViewModel_Factory(Providers.asDaggerProvider(mainRouterProvider), Providers.asDaggerProvider(setActivityResultProvider));
  }

  public static WebPageViewModel_Factory create(Provider<MainRouter> mainRouterProvider,
      Provider<SetActivityResult> setActivityResultProvider) {
    return new WebPageViewModel_Factory(mainRouterProvider, setActivityResultProvider);
  }

  public static WebPageViewModel newInstance(MainRouter mainRouter,
      SetActivityResult setActivityResult) {
    return new WebPageViewModel(mainRouter, setActivityResult);
  }
}
