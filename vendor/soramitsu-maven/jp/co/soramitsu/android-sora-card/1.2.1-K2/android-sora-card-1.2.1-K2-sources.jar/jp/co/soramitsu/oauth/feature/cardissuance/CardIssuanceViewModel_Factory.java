package jp.co.soramitsu.oauth.feature.cardissuance;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;
import jp.co.soramitsu.oauth.base.navigation.SetActivityResult;
import jp.co.soramitsu.oauth.common.domain.PWOAuthClientProxy;
import jp.co.soramitsu.oauth.common.domain.PriceInteractor;
import jp.co.soramitsu.oauth.feature.session.domain.UserSessionRepository;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CardIssuanceViewModel_Factory implements Factory<CardIssuanceViewModel> {
  private final Provider<SetActivityResult> setActivityResultProvider;

  private final Provider<UserSessionRepository> userSessionRepositoryProvider;

  private final Provider<PriceInteractor> priceInteractorProvider;

  private final Provider<MainRouter> mainRouterProvider;

  private final Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider;

  public CardIssuanceViewModel_Factory(Provider<SetActivityResult> setActivityResultProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider,
      Provider<PriceInteractor> priceInteractorProvider, Provider<MainRouter> mainRouterProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    this.setActivityResultProvider = setActivityResultProvider;
    this.userSessionRepositoryProvider = userSessionRepositoryProvider;
    this.priceInteractorProvider = priceInteractorProvider;
    this.mainRouterProvider = mainRouterProvider;
    this.pwoAuthClientProxyProvider = pwoAuthClientProxyProvider;
  }

  @Override
  public CardIssuanceViewModel get() {
    return newInstance(setActivityResultProvider.get(), userSessionRepositoryProvider.get(), priceInteractorProvider.get(), mainRouterProvider.get(), pwoAuthClientProxyProvider.get());
  }

  public static CardIssuanceViewModel_Factory create(
      javax.inject.Provider<SetActivityResult> setActivityResultProvider,
      javax.inject.Provider<UserSessionRepository> userSessionRepositoryProvider,
      javax.inject.Provider<PriceInteractor> priceInteractorProvider,
      javax.inject.Provider<MainRouter> mainRouterProvider,
      javax.inject.Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    return new CardIssuanceViewModel_Factory(Providers.asDaggerProvider(setActivityResultProvider), Providers.asDaggerProvider(userSessionRepositoryProvider), Providers.asDaggerProvider(priceInteractorProvider), Providers.asDaggerProvider(mainRouterProvider), Providers.asDaggerProvider(pwoAuthClientProxyProvider));
  }

  public static CardIssuanceViewModel_Factory create(
      Provider<SetActivityResult> setActivityResultProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider,
      Provider<PriceInteractor> priceInteractorProvider, Provider<MainRouter> mainRouterProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    return new CardIssuanceViewModel_Factory(setActivityResultProvider, userSessionRepositoryProvider, priceInteractorProvider, mainRouterProvider, pwoAuthClientProxyProvider);
  }

  public static CardIssuanceViewModel newInstance(SetActivityResult setActivityResult,
      UserSessionRepository userSessionRepository, PriceInteractor priceInteractor,
      MainRouter mainRouter, PWOAuthClientProxy pwoAuthClientProxy) {
    return new CardIssuanceViewModel(setActivityResult, userSessionRepository, priceInteractor, mainRouter, pwoAuthClientProxy);
  }
}
