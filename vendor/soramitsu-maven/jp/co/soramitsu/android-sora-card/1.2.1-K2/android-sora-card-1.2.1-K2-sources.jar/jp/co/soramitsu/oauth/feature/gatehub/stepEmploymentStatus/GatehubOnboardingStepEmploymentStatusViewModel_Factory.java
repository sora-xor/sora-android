package jp.co.soramitsu.oauth.feature.gatehub.stepEmploymentStatus;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;
import jp.co.soramitsu.oauth.base.navigation.SetActivityResult;
import jp.co.soramitsu.oauth.base.sdk.InMemoryRepo;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class GatehubOnboardingStepEmploymentStatusViewModel_Factory implements Factory<GatehubOnboardingStepEmploymentStatusViewModel> {
  private final Provider<MainRouter> mainRouterProvider;

  private final Provider<SetActivityResult> setActivityResultProvider;

  private final Provider<InMemoryRepo> inMemoryRepoProvider;

  public GatehubOnboardingStepEmploymentStatusViewModel_Factory(
      Provider<MainRouter> mainRouterProvider,
      Provider<SetActivityResult> setActivityResultProvider,
      Provider<InMemoryRepo> inMemoryRepoProvider) {
    this.mainRouterProvider = mainRouterProvider;
    this.setActivityResultProvider = setActivityResultProvider;
    this.inMemoryRepoProvider = inMemoryRepoProvider;
  }

  @Override
  public GatehubOnboardingStepEmploymentStatusViewModel get() {
    return newInstance(mainRouterProvider.get(), setActivityResultProvider.get(), inMemoryRepoProvider.get());
  }

  public static GatehubOnboardingStepEmploymentStatusViewModel_Factory create(
      javax.inject.Provider<MainRouter> mainRouterProvider,
      javax.inject.Provider<SetActivityResult> setActivityResultProvider,
      javax.inject.Provider<InMemoryRepo> inMemoryRepoProvider) {
    return new GatehubOnboardingStepEmploymentStatusViewModel_Factory(Providers.asDaggerProvider(mainRouterProvider), Providers.asDaggerProvider(setActivityResultProvider), Providers.asDaggerProvider(inMemoryRepoProvider));
  }

  public static GatehubOnboardingStepEmploymentStatusViewModel_Factory create(
      Provider<MainRouter> mainRouterProvider,
      Provider<SetActivityResult> setActivityResultProvider,
      Provider<InMemoryRepo> inMemoryRepoProvider) {
    return new GatehubOnboardingStepEmploymentStatusViewModel_Factory(mainRouterProvider, setActivityResultProvider, inMemoryRepoProvider);
  }

  public static GatehubOnboardingStepEmploymentStatusViewModel newInstance(MainRouter mainRouter,
      SetActivityResult setActivityResult, InMemoryRepo inMemoryRepo) {
    return new GatehubOnboardingStepEmploymentStatusViewModel(mainRouter, setActivityResult, inMemoryRepo);
  }
}
