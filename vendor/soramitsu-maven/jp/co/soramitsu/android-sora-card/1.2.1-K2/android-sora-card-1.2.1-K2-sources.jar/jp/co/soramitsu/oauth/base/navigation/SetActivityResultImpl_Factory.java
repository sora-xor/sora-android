package jp.co.soramitsu.oauth.base.navigation;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.common.domain.CurrentActivityRetriever;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class SetActivityResultImpl_Factory implements Factory<SetActivityResultImpl> {
  private final Provider<CurrentActivityRetriever> currentActivityRetrieverProvider;

  public SetActivityResultImpl_Factory(
      Provider<CurrentActivityRetriever> currentActivityRetrieverProvider) {
    this.currentActivityRetrieverProvider = currentActivityRetrieverProvider;
  }

  @Override
  public SetActivityResultImpl get() {
    return newInstance(currentActivityRetrieverProvider.get());
  }

  public static SetActivityResultImpl_Factory create(
      javax.inject.Provider<CurrentActivityRetriever> currentActivityRetrieverProvider) {
    return new SetActivityResultImpl_Factory(Providers.asDaggerProvider(currentActivityRetrieverProvider));
  }

  public static SetActivityResultImpl_Factory create(
      Provider<CurrentActivityRetriever> currentActivityRetrieverProvider) {
    return new SetActivityResultImpl_Factory(currentActivityRetrieverProvider);
  }

  public static SetActivityResultImpl newInstance(
      CurrentActivityRetriever currentActivityRetriever) {
    return new SetActivityResultImpl(currentActivityRetriever);
  }
}
