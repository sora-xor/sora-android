package jp.co.soramitsu.oauth.feature.kyc.result;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.SetActivityResult;
import jp.co.soramitsu.oauth.common.domain.PWOAuthClientProxy;
import jp.co.soramitsu.oauth.feature.session.domain.UserSessionRepository;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class VerificationSuccessfulViewModel_Factory implements Factory<VerificationSuccessfulViewModel> {
  private final Provider<SetActivityResult> setActivityResultProvider;

  private final Provider<UserSessionRepository> userSessionRepositoryProvider;

  private final Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider;

  public VerificationSuccessfulViewModel_Factory(
      Provider<SetActivityResult> setActivityResultProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    this.setActivityResultProvider = setActivityResultProvider;
    this.userSessionRepositoryProvider = userSessionRepositoryProvider;
    this.pwoAuthClientProxyProvider = pwoAuthClientProxyProvider;
  }

  @Override
  public VerificationSuccessfulViewModel get() {
    return newInstance(setActivityResultProvider.get(), userSessionRepositoryProvider.get(), pwoAuthClientProxyProvider.get());
  }

  public static VerificationSuccessfulViewModel_Factory create(
      javax.inject.Provider<SetActivityResult> setActivityResultProvider,
      javax.inject.Provider<UserSessionRepository> userSessionRepositoryProvider,
      javax.inject.Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    return new VerificationSuccessfulViewModel_Factory(Providers.asDaggerProvider(setActivityResultProvider), Providers.asDaggerProvider(userSessionRepositoryProvider), Providers.asDaggerProvider(pwoAuthClientProxyProvider));
  }

  public static VerificationSuccessfulViewModel_Factory create(
      Provider<SetActivityResult> setActivityResultProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    return new VerificationSuccessfulViewModel_Factory(setActivityResultProvider, userSessionRepositoryProvider, pwoAuthClientProxyProvider);
  }

  public static VerificationSuccessfulViewModel newInstance(SetActivityResult setActivityResult,
      UserSessionRepository userSessionRepository, PWOAuthClientProxy pwoAuthClientProxy) {
    return new VerificationSuccessfulViewModel(setActivityResult, userSessionRepository, pwoAuthClientProxy);
  }
}
