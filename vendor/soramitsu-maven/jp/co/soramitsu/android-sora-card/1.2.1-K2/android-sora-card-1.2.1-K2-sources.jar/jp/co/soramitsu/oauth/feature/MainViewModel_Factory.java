package jp.co.soramitsu.oauth.feature;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;
import jp.co.soramitsu.oauth.base.navigation.SetActivityResult;
import jp.co.soramitsu.oauth.base.sdk.InMemoryRepo;
import jp.co.soramitsu.oauth.common.domain.KycRepository;
import jp.co.soramitsu.oauth.common.domain.PWOAuthClientProxy;
import jp.co.soramitsu.oauth.feature.gatehub.GateHubRepository;
import jp.co.soramitsu.oauth.feature.session.domain.UserSessionRepository;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class MainViewModel_Factory implements Factory<MainViewModel> {
  private final Provider<UserSessionRepository> userSessionRepositoryProvider;

  private final Provider<KycRepository> kycRepositoryProvider;

  private final Provider<MainRouter> mainRouterProvider;

  private final Provider<InMemoryRepo> inMemoryRepoProvider;

  private final Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider;

  private final Provider<AccessTokenValidator> tokenValidatorProvider;

  private final Provider<SetActivityResult> setActivityResultProvider;

  private final Provider<GateHubRepository> gateHubRepositoryProvider;

  public MainViewModel_Factory(Provider<UserSessionRepository> userSessionRepositoryProvider,
      Provider<KycRepository> kycRepositoryProvider, Provider<MainRouter> mainRouterProvider,
      Provider<InMemoryRepo> inMemoryRepoProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider,
      Provider<AccessTokenValidator> tokenValidatorProvider,
      Provider<SetActivityResult> setActivityResultProvider,
      Provider<GateHubRepository> gateHubRepositoryProvider) {
    this.userSessionRepositoryProvider = userSessionRepositoryProvider;
    this.kycRepositoryProvider = kycRepositoryProvider;
    this.mainRouterProvider = mainRouterProvider;
    this.inMemoryRepoProvider = inMemoryRepoProvider;
    this.pwoAuthClientProxyProvider = pwoAuthClientProxyProvider;
    this.tokenValidatorProvider = tokenValidatorProvider;
    this.setActivityResultProvider = setActivityResultProvider;
    this.gateHubRepositoryProvider = gateHubRepositoryProvider;
  }

  @Override
  public MainViewModel get() {
    return newInstance(userSessionRepositoryProvider.get(), kycRepositoryProvider.get(), mainRouterProvider.get(), inMemoryRepoProvider.get(), pwoAuthClientProxyProvider.get(), tokenValidatorProvider.get(), setActivityResultProvider.get(), gateHubRepositoryProvider.get());
  }

  public static MainViewModel_Factory create(
      javax.inject.Provider<UserSessionRepository> userSessionRepositoryProvider,
      javax.inject.Provider<KycRepository> kycRepositoryProvider,
      javax.inject.Provider<MainRouter> mainRouterProvider,
      javax.inject.Provider<InMemoryRepo> inMemoryRepoProvider,
      javax.inject.Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider,
      javax.inject.Provider<AccessTokenValidator> tokenValidatorProvider,
      javax.inject.Provider<SetActivityResult> setActivityResultProvider,
      javax.inject.Provider<GateHubRepository> gateHubRepositoryProvider) {
    return new MainViewModel_Factory(Providers.asDaggerProvider(userSessionRepositoryProvider), Providers.asDaggerProvider(kycRepositoryProvider), Providers.asDaggerProvider(mainRouterProvider), Providers.asDaggerProvider(inMemoryRepoProvider), Providers.asDaggerProvider(pwoAuthClientProxyProvider), Providers.asDaggerProvider(tokenValidatorProvider), Providers.asDaggerProvider(setActivityResultProvider), Providers.asDaggerProvider(gateHubRepositoryProvider));
  }

  public static MainViewModel_Factory create(
      Provider<UserSessionRepository> userSessionRepositoryProvider,
      Provider<KycRepository> kycRepositoryProvider, Provider<MainRouter> mainRouterProvider,
      Provider<InMemoryRepo> inMemoryRepoProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider,
      Provider<AccessTokenValidator> tokenValidatorProvider,
      Provider<SetActivityResult> setActivityResultProvider,
      Provider<GateHubRepository> gateHubRepositoryProvider) {
    return new MainViewModel_Factory(userSessionRepositoryProvider, kycRepositoryProvider, mainRouterProvider, inMemoryRepoProvider, pwoAuthClientProxyProvider, tokenValidatorProvider, setActivityResultProvider, gateHubRepositoryProvider);
  }

  public static MainViewModel newInstance(UserSessionRepository userSessionRepository,
      KycRepository kycRepository, MainRouter mainRouter, InMemoryRepo inMemoryRepo,
      PWOAuthClientProxy pwoAuthClientProxy, AccessTokenValidator tokenValidator,
      SetActivityResult setActivityResult, GateHubRepository gateHubRepository) {
    return new MainViewModel(userSessionRepository, kycRepository, mainRouter, inMemoryRepo, pwoAuthClientProxy, tokenValidator, setActivityResult, gateHubRepository);
  }
}
