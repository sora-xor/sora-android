package jp.co.soramitsu.oauth.common.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

enum class KycStatus {

    Started,
    Completed,
    Failed,
    Rejected,
    Successful,
    Retry,
}

enum class VerificationStatus {

    None,
    Pending,
    Accepted,
    Rejected,
}

enum class IbanStatus {

    None,
    Pending,
    Rejected,
}

@Serializable
data class KycResponse(
    @SerialName("kyc_id") val kycID: String,
    @SerialName("person_id") val personID: String,
    @SerialName("user_reference_number") val userReferenceNumber: String,
    @SerialName("reference_id") val referenceID: String? = null,
    @SerialName("kyc_status") val kycStatus: KycStatus,
    @SerialName("verification_status") val verificationStatus: VerificationStatus,
    @SerialName("iban_status") val ibanStatus: IbanStatus,
    @SerialName("update_time") val updateTime: Int,
    @SerialName("additional_description") val additionalDescription: String? = null,
    @SerialName("rejection_reasons") val rejectionReasons: List<KycResponseRejectionReason>? = null,
)

internal val emptyKycResponse = KycResponse(
    "", "", "", "", KycStatus.Rejected, VerificationStatus.None, IbanStatus.None, 1000, "", null,
)

@Serializable
data class KycResponseRejectionReason(
    @SerialName("Description") val desc: String,
)
