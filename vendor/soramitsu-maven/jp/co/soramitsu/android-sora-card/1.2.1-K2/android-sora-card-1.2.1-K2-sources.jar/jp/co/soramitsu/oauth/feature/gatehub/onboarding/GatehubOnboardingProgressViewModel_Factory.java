package jp.co.soramitsu.oauth.feature.gatehub.onboarding;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.SetActivityResult;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class GatehubOnboardingProgressViewModel_Factory implements Factory<GatehubOnboardingProgressViewModel> {
  private final Provider<SetActivityResult> setActivityResultProvider;

  public GatehubOnboardingProgressViewModel_Factory(
      Provider<SetActivityResult> setActivityResultProvider) {
    this.setActivityResultProvider = setActivityResultProvider;
  }

  @Override
  public GatehubOnboardingProgressViewModel get() {
    return newInstance(setActivityResultProvider.get());
  }

  public static GatehubOnboardingProgressViewModel_Factory create(
      javax.inject.Provider<SetActivityResult> setActivityResultProvider) {
    return new GatehubOnboardingProgressViewModel_Factory(Providers.asDaggerProvider(setActivityResultProvider));
  }

  public static GatehubOnboardingProgressViewModel_Factory create(
      Provider<SetActivityResult> setActivityResultProvider) {
    return new GatehubOnboardingProgressViewModel_Factory(setActivityResultProvider);
  }

  public static GatehubOnboardingProgressViewModel newInstance(
      SetActivityResult setActivityResult) {
    return new GatehubOnboardingProgressViewModel(setActivityResult);
  }
}
