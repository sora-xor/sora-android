package jp.co.soramitsu.oauth.feature.gatehub.rejected;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class GatehubRejectedViewModel_Factory implements Factory<GatehubRejectedViewModel> {
  private final Provider<MainRouter> mainRouterProvider;

  public GatehubRejectedViewModel_Factory(Provider<MainRouter> mainRouterProvider) {
    this.mainRouterProvider = mainRouterProvider;
  }

  @Override
  public GatehubRejectedViewModel get() {
    return newInstance(mainRouterProvider.get());
  }

  public static GatehubRejectedViewModel_Factory create(
      javax.inject.Provider<MainRouter> mainRouterProvider) {
    return new GatehubRejectedViewModel_Factory(Providers.asDaggerProvider(mainRouterProvider));
  }

  public static GatehubRejectedViewModel_Factory create(Provider<MainRouter> mainRouterProvider) {
    return new GatehubRejectedViewModel_Factory(mainRouterProvider);
  }

  public static GatehubRejectedViewModel newInstance(MainRouter mainRouter) {
    return new GatehubRejectedViewModel(mainRouter);
  }
}
