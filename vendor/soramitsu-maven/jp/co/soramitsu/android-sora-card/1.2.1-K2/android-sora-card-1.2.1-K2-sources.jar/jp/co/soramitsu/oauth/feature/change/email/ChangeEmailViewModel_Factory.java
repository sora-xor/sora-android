package jp.co.soramitsu.oauth.feature.change.email;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;
import jp.co.soramitsu.oauth.common.domain.PWOAuthClientProxy;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ChangeEmailViewModel_Factory implements Factory<ChangeEmailViewModel> {
  private final Provider<MainRouter> mainRouterProvider;

  private final Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider;

  public ChangeEmailViewModel_Factory(Provider<MainRouter> mainRouterProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    this.mainRouterProvider = mainRouterProvider;
    this.pwoAuthClientProxyProvider = pwoAuthClientProxyProvider;
  }

  @Override
  public ChangeEmailViewModel get() {
    return newInstance(mainRouterProvider.get(), pwoAuthClientProxyProvider.get());
  }

  public static ChangeEmailViewModel_Factory create(
      javax.inject.Provider<MainRouter> mainRouterProvider,
      javax.inject.Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    return new ChangeEmailViewModel_Factory(Providers.asDaggerProvider(mainRouterProvider), Providers.asDaggerProvider(pwoAuthClientProxyProvider));
  }

  public static ChangeEmailViewModel_Factory create(Provider<MainRouter> mainRouterProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    return new ChangeEmailViewModel_Factory(mainRouterProvider, pwoAuthClientProxyProvider);
  }

  public static ChangeEmailViewModel newInstance(MainRouter mainRouter,
      PWOAuthClientProxy pwoAuthClientProxy) {
    return new ChangeEmailViewModel(mainRouter, pwoAuthClientProxy);
  }
}
