package jp.co.soramitsu.oauth.feature.telephone;

import android.content.Context;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("dagger.hilt.android.qualifiers.ApplicationContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class LocaleService_Factory implements Factory<LocaleService> {
  private final Provider<Context> cProvider;

  public LocaleService_Factory(Provider<Context> cProvider) {
    this.cProvider = cProvider;
  }

  @Override
  public LocaleService get() {
    return newInstance(cProvider.get());
  }

  public static LocaleService_Factory create(javax.inject.Provider<Context> cProvider) {
    return new LocaleService_Factory(Providers.asDaggerProvider(cProvider));
  }

  public static LocaleService_Factory create(Provider<Context> cProvider) {
    return new LocaleService_Factory(cProvider);
  }

  public static LocaleService newInstance(Context c) {
    return new LocaleService(c);
  }
}
