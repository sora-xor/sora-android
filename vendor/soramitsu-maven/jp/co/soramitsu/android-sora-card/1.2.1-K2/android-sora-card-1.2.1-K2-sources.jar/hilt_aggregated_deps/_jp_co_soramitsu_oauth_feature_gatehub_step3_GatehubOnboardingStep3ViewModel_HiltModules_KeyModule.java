package hilt_aggregated_deps;

import dagger.hilt.processor.internal.aggregateddeps.AggregatedDeps;
import javax.annotation.processing.Generated;

/**
 * This class should only be referenced by generated code! This class aggregates information across multiple compilations.
 */
@AggregatedDeps(
    components = "dagger.hilt.android.components.ActivityRetainedComponent",
    modules = "jp.co.soramitsu.oauth.feature.gatehub.step3.GatehubOnboardingStep3ViewModel_HiltModules.KeyModule"
)
@Generated("dagger.hilt.processor.internal.aggregateddeps.AggregatedDepsGenerator")
public class _jp_co_soramitsu_oauth_feature_gatehub_step3_GatehubOnboardingStep3ViewModel_HiltModules_KeyModule {
}
