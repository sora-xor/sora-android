package jp.co.soramitsu.oauth.common.di;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.sdk.InMemoryRepo;
import jp.co.soramitsu.oauth.common.domain.KycRepository;
import jp.co.soramitsu.oauth.feature.session.domain.UserSessionRepository;
import jp.co.soramitsu.oauth.network.SoraCardNetworkClient;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CommonModule_ProvideKycRepositoryFactory implements Factory<KycRepository> {
  private final CommonModule module;

  private final Provider<SoraCardNetworkClient> apiClientProvider;

  private final Provider<InMemoryRepo> inMemoryRepoProvider;

  private final Provider<UserSessionRepository> userSessionRepositoryProvider;

  public CommonModule_ProvideKycRepositoryFactory(CommonModule module,
      Provider<SoraCardNetworkClient> apiClientProvider,
      Provider<InMemoryRepo> inMemoryRepoProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider) {
    this.module = module;
    this.apiClientProvider = apiClientProvider;
    this.inMemoryRepoProvider = inMemoryRepoProvider;
    this.userSessionRepositoryProvider = userSessionRepositoryProvider;
  }

  @Override
  public KycRepository get() {
    return provideKycRepository(module, apiClientProvider.get(), inMemoryRepoProvider.get(), userSessionRepositoryProvider.get());
  }

  public static CommonModule_ProvideKycRepositoryFactory create(CommonModule module,
      javax.inject.Provider<SoraCardNetworkClient> apiClientProvider,
      javax.inject.Provider<InMemoryRepo> inMemoryRepoProvider,
      javax.inject.Provider<UserSessionRepository> userSessionRepositoryProvider) {
    return new CommonModule_ProvideKycRepositoryFactory(module, Providers.asDaggerProvider(apiClientProvider), Providers.asDaggerProvider(inMemoryRepoProvider), Providers.asDaggerProvider(userSessionRepositoryProvider));
  }

  public static CommonModule_ProvideKycRepositoryFactory create(CommonModule module,
      Provider<SoraCardNetworkClient> apiClientProvider,
      Provider<InMemoryRepo> inMemoryRepoProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider) {
    return new CommonModule_ProvideKycRepositoryFactory(module, apiClientProvider, inMemoryRepoProvider, userSessionRepositoryProvider);
  }

  public static KycRepository provideKycRepository(CommonModule instance,
      SoraCardNetworkClient apiClient, InMemoryRepo inMemoryRepo,
      UserSessionRepository userSessionRepository) {
    return Preconditions.checkNotNullFromProvides(instance.provideKycRepository(apiClient, inMemoryRepo, userSessionRepository));
  }
}
