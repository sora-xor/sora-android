package jp.co.soramitsu.oauth.feature.getmorexor;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;
import jp.co.soramitsu.oauth.base.navigation.SetActivityResult;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class GetMoreXorViewModel_Factory implements Factory<GetMoreXorViewModel> {
  private final Provider<SetActivityResult> setActivityResultProvider;

  private final Provider<MainRouter> mainRouterProvider;

  public GetMoreXorViewModel_Factory(Provider<SetActivityResult> setActivityResultProvider,
      Provider<MainRouter> mainRouterProvider) {
    this.setActivityResultProvider = setActivityResultProvider;
    this.mainRouterProvider = mainRouterProvider;
  }

  @Override
  public GetMoreXorViewModel get() {
    return newInstance(setActivityResultProvider.get(), mainRouterProvider.get());
  }

  public static GetMoreXorViewModel_Factory create(
      javax.inject.Provider<SetActivityResult> setActivityResultProvider,
      javax.inject.Provider<MainRouter> mainRouterProvider) {
    return new GetMoreXorViewModel_Factory(Providers.asDaggerProvider(setActivityResultProvider), Providers.asDaggerProvider(mainRouterProvider));
  }

  public static GetMoreXorViewModel_Factory create(
      Provider<SetActivityResult> setActivityResultProvider,
      Provider<MainRouter> mainRouterProvider) {
    return new GetMoreXorViewModel_Factory(setActivityResultProvider, mainRouterProvider);
  }

  public static GetMoreXorViewModel newInstance(SetActivityResult setActivityResult,
      MainRouter mainRouter) {
    return new GetMoreXorViewModel(setActivityResult, mainRouter);
  }
}
