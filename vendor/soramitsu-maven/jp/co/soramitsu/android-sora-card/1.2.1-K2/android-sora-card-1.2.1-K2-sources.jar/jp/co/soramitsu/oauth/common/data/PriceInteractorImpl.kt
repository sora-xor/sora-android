package jp.co.soramitsu.oauth.common.data

import jp.co.soramitsu.androidfoundation.format.unsafeCast
import jp.co.soramitsu.oauth.base.sdk.InMemoryRepo
import jp.co.soramitsu.oauth.base.sdk.contract.SoraCardFlow
import jp.co.soramitsu.oauth.common.domain.KycRepository
import jp.co.soramitsu.oauth.common.domain.PriceInteractor
import jp.co.soramitsu.oauth.common.domain.PriceInteractor.Companion.KYC_REQUIRED_BALANCE
import jp.co.soramitsu.oauth.common.model.EuroLiquiditySufficiency
import jp.co.soramitsu.oauth.common.model.XorLiquiditySufficiency
import jp.co.soramitsu.oauth.feature.session.domain.UserSessionRepository

class PriceInteractorImpl(
    private val userSessionRepository: UserSessionRepository,
    private val inMemoryCache: InMemoryRepo,
    private val kycRepository: KycRepository,
) : PriceInteractor {

    override suspend fun calculateXorLiquiditySufficiency(): Result<XorLiquiditySufficiency> {
        val accessToken = userSessionRepository.getAccessToken()

        return kycRepository.getCurrentXorEuroPrice(accessToken)
            .map {
                val xorLiquidityFullPrice =
                    KYC_REQUIRED_BALANCE.div(it)

                XorLiquiditySufficiency(
                    xorInsufficiency = xorLiquidityFullPrice - inMemoryCache.flow!!.unsafeCast<SoraCardFlow.SoraCardKycFlow>().userAvailableXorAmount,
                    xorLiquidityFullPrice = xorLiquidityFullPrice,
                )
            }
    }

    override suspend fun calculateEuroLiquiditySufficiency(): Result<EuroLiquiditySufficiency> {
        val accessToken = userSessionRepository.getAccessToken()

        return kycRepository.getCurrentXorEuroPrice(accessToken)
            .map {
                val userAvailableEuroAmount =
                    inMemoryCache.flow!!.unsafeCast<SoraCardFlow.SoraCardKycFlow>().userAvailableXorAmount.times(
                        it,
                    )

                EuroLiquiditySufficiency(
                    euroInsufficiency = KYC_REQUIRED_BALANCE - userAvailableEuroAmount,
                    euroLiquidityFullPrice = KYC_REQUIRED_BALANCE,
                )
            }
    }

    override suspend fun calculateCardIssuancePrice(): String = kycRepository.getApplicationFee()

    override suspend fun calculateKycAttemptPrice(): String = kycRepository.getRetryFee()
}
