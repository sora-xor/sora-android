package jp.co.soramitsu.oauth.feature.terms.and.conditions;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;
import jp.co.soramitsu.oauth.base.navigation.SetActivityResult;
import jp.co.soramitsu.oauth.feature.session.domain.UserSessionRepository;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class TermsAndConditionsViewModel_Factory implements Factory<TermsAndConditionsViewModel> {
  private final Provider<MainRouter> mainRouterProvider;

  private final Provider<SetActivityResult> setActivityResultProvider;

  private final Provider<UserSessionRepository> userSessionRepositoryProvider;

  public TermsAndConditionsViewModel_Factory(Provider<MainRouter> mainRouterProvider,
      Provider<SetActivityResult> setActivityResultProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider) {
    this.mainRouterProvider = mainRouterProvider;
    this.setActivityResultProvider = setActivityResultProvider;
    this.userSessionRepositoryProvider = userSessionRepositoryProvider;
  }

  @Override
  public TermsAndConditionsViewModel get() {
    return newInstance(mainRouterProvider.get(), setActivityResultProvider.get(), userSessionRepositoryProvider.get());
  }

  public static TermsAndConditionsViewModel_Factory create(
      javax.inject.Provider<MainRouter> mainRouterProvider,
      javax.inject.Provider<SetActivityResult> setActivityResultProvider,
      javax.inject.Provider<UserSessionRepository> userSessionRepositoryProvider) {
    return new TermsAndConditionsViewModel_Factory(Providers.asDaggerProvider(mainRouterProvider), Providers.asDaggerProvider(setActivityResultProvider), Providers.asDaggerProvider(userSessionRepositoryProvider));
  }

  public static TermsAndConditionsViewModel_Factory create(Provider<MainRouter> mainRouterProvider,
      Provider<SetActivityResult> setActivityResultProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider) {
    return new TermsAndConditionsViewModel_Factory(mainRouterProvider, setActivityResultProvider, userSessionRepositoryProvider);
  }

  public static TermsAndConditionsViewModel newInstance(MainRouter mainRouter,
      SetActivityResult setActivityResult, UserSessionRepository userSessionRepository) {
    return new TermsAndConditionsViewModel(mainRouter, setActivityResult, userSessionRepository);
  }
}
