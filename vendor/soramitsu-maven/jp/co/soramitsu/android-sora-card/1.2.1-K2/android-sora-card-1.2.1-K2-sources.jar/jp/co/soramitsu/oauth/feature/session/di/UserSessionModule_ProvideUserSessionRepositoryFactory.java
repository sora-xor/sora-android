package jp.co.soramitsu.oauth.feature.session.di;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.data.SoraCardDataStore;
import jp.co.soramitsu.oauth.feature.session.domain.UserSessionRepository;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class UserSessionModule_ProvideUserSessionRepositoryFactory implements Factory<UserSessionRepository> {
  private final UserSessionModule module;

  private final Provider<SoraCardDataStore> dataStoreProvider;

  public UserSessionModule_ProvideUserSessionRepositoryFactory(UserSessionModule module,
      Provider<SoraCardDataStore> dataStoreProvider) {
    this.module = module;
    this.dataStoreProvider = dataStoreProvider;
  }

  @Override
  public UserSessionRepository get() {
    return provideUserSessionRepository(module, dataStoreProvider.get());
  }

  public static UserSessionModule_ProvideUserSessionRepositoryFactory create(
      UserSessionModule module, javax.inject.Provider<SoraCardDataStore> dataStoreProvider) {
    return new UserSessionModule_ProvideUserSessionRepositoryFactory(module, Providers.asDaggerProvider(dataStoreProvider));
  }

  public static UserSessionModule_ProvideUserSessionRepositoryFactory create(
      UserSessionModule module, Provider<SoraCardDataStore> dataStoreProvider) {
    return new UserSessionModule_ProvideUserSessionRepositoryFactory(module, dataStoreProvider);
  }

  public static UserSessionRepository provideUserSessionRepository(UserSessionModule instance,
      SoraCardDataStore dataStore) {
    return Preconditions.checkNotNullFromProvides(instance.provideUserSessionRepository(dataStore));
  }
}
