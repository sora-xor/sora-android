package jp.co.soramitsu.oauth.feature;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.common.domain.PWOAuthClientProxy;
import jp.co.soramitsu.oauth.feature.session.domain.UserSessionRepository;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class AccessTokenValidator_Factory implements Factory<AccessTokenValidator> {
  private final Provider<UserSessionRepository> userSessionRepositoryProvider;

  private final Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider;

  public AccessTokenValidator_Factory(Provider<UserSessionRepository> userSessionRepositoryProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    this.userSessionRepositoryProvider = userSessionRepositoryProvider;
    this.pwoAuthClientProxyProvider = pwoAuthClientProxyProvider;
  }

  @Override
  public AccessTokenValidator get() {
    return newInstance(userSessionRepositoryProvider.get(), pwoAuthClientProxyProvider.get());
  }

  public static AccessTokenValidator_Factory create(
      javax.inject.Provider<UserSessionRepository> userSessionRepositoryProvider,
      javax.inject.Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    return new AccessTokenValidator_Factory(Providers.asDaggerProvider(userSessionRepositoryProvider), Providers.asDaggerProvider(pwoAuthClientProxyProvider));
  }

  public static AccessTokenValidator_Factory create(
      Provider<UserSessionRepository> userSessionRepositoryProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    return new AccessTokenValidator_Factory(userSessionRepositoryProvider, pwoAuthClientProxyProvider);
  }

  public static AccessTokenValidator newInstance(UserSessionRepository userSessionRepository,
      PWOAuthClientProxy pwoAuthClientProxy) {
    return new AccessTokenValidator(userSessionRepository, pwoAuthClientProxy);
  }
}
