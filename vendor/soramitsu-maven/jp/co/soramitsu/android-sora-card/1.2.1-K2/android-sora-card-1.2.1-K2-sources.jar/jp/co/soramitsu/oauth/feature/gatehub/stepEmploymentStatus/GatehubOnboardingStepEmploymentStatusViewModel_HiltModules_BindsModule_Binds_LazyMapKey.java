package jp.co.soramitsu.oauth.feature.gatehub.stepEmploymentStatus;

import dagger.internal.DaggerGenerated;
import dagger.internal.IdentifierNameString;
import dagger.internal.KeepFieldType;
import javax.annotation.processing.Generated;

@IdentifierNameString
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class GatehubOnboardingStepEmploymentStatusViewModel_HiltModules_BindsModule_Binds_LazyMapKey {
  @KeepFieldType
  static GatehubOnboardingStepEmploymentStatusViewModel keepFieldType;

  public static String lazyClassKeyName = "jp.co.soramitsu.oauth.feature.gatehub.stepEmploymentStatus.GatehubOnboardingStepEmploymentStatusViewModel";
}
