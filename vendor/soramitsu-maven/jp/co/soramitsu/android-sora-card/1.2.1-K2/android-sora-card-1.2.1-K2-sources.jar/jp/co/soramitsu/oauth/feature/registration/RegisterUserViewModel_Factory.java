package jp.co.soramitsu.oauth.feature.registration;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class RegisterUserViewModel_Factory implements Factory<RegisterUserViewModel> {
  private final Provider<MainRouter> mainRouterProvider;

  public RegisterUserViewModel_Factory(Provider<MainRouter> mainRouterProvider) {
    this.mainRouterProvider = mainRouterProvider;
  }

  @Override
  public RegisterUserViewModel get() {
    return newInstance(mainRouterProvider.get());
  }

  public static RegisterUserViewModel_Factory create(
      javax.inject.Provider<MainRouter> mainRouterProvider) {
    return new RegisterUserViewModel_Factory(Providers.asDaggerProvider(mainRouterProvider));
  }

  public static RegisterUserViewModel_Factory create(Provider<MainRouter> mainRouterProvider) {
    return new RegisterUserViewModel_Factory(mainRouterProvider);
  }

  public static RegisterUserViewModel newInstance(MainRouter mainRouter) {
    return new RegisterUserViewModel(mainRouter);
  }
}
