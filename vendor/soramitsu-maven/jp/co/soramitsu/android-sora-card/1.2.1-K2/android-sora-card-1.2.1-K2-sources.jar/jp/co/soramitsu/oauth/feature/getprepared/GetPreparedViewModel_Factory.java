package jp.co.soramitsu.oauth.feature.getprepared;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.SetActivityResult;
import jp.co.soramitsu.oauth.common.domain.KycRepository;
import jp.co.soramitsu.oauth.common.domain.PWOAuthClientProxy;
import jp.co.soramitsu.oauth.common.domain.PriceInteractor;
import jp.co.soramitsu.oauth.feature.session.domain.UserSessionRepository;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class GetPreparedViewModel_Factory implements Factory<GetPreparedViewModel> {
  private final Provider<SetActivityResult> setActivityResultProvider;

  private final Provider<UserSessionRepository> userSessionRepositoryProvider;

  private final Provider<KycRepository> kycRepositoryProvider;

  private final Provider<PriceInteractor> priceInteractorProvider;

  private final Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider;

  public GetPreparedViewModel_Factory(Provider<SetActivityResult> setActivityResultProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider,
      Provider<KycRepository> kycRepositoryProvider,
      Provider<PriceInteractor> priceInteractorProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    this.setActivityResultProvider = setActivityResultProvider;
    this.userSessionRepositoryProvider = userSessionRepositoryProvider;
    this.kycRepositoryProvider = kycRepositoryProvider;
    this.priceInteractorProvider = priceInteractorProvider;
    this.pwoAuthClientProxyProvider = pwoAuthClientProxyProvider;
  }

  @Override
  public GetPreparedViewModel get() {
    return newInstance(setActivityResultProvider.get(), userSessionRepositoryProvider.get(), kycRepositoryProvider.get(), priceInteractorProvider.get(), pwoAuthClientProxyProvider.get());
  }

  public static GetPreparedViewModel_Factory create(
      javax.inject.Provider<SetActivityResult> setActivityResultProvider,
      javax.inject.Provider<UserSessionRepository> userSessionRepositoryProvider,
      javax.inject.Provider<KycRepository> kycRepositoryProvider,
      javax.inject.Provider<PriceInteractor> priceInteractorProvider,
      javax.inject.Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    return new GetPreparedViewModel_Factory(Providers.asDaggerProvider(setActivityResultProvider), Providers.asDaggerProvider(userSessionRepositoryProvider), Providers.asDaggerProvider(kycRepositoryProvider), Providers.asDaggerProvider(priceInteractorProvider), Providers.asDaggerProvider(pwoAuthClientProxyProvider));
  }

  public static GetPreparedViewModel_Factory create(
      Provider<SetActivityResult> setActivityResultProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider,
      Provider<KycRepository> kycRepositoryProvider,
      Provider<PriceInteractor> priceInteractorProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    return new GetPreparedViewModel_Factory(setActivityResultProvider, userSessionRepositoryProvider, kycRepositoryProvider, priceInteractorProvider, pwoAuthClientProxyProvider);
  }

  public static GetPreparedViewModel newInstance(SetActivityResult setActivityResult,
      UserSessionRepository userSessionRepository, KycRepository kycRepository,
      PriceInteractor priceInteractor, PWOAuthClientProxy pwoAuthClientProxy) {
    return new GetPreparedViewModel(setActivityResult, userSessionRepository, kycRepository, priceInteractor, pwoAuthClientProxy);
  }
}
