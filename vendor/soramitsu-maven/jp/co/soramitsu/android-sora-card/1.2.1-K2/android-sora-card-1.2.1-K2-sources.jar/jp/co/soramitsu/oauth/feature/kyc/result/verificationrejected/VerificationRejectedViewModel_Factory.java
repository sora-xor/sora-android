package jp.co.soramitsu.oauth.feature.kyc.result.verificationrejected;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.navigation.MainRouter;
import jp.co.soramitsu.oauth.base.navigation.SetActivityResult;
import jp.co.soramitsu.oauth.common.domain.KycRepository;
import jp.co.soramitsu.oauth.common.domain.PWOAuthClientProxy;
import jp.co.soramitsu.oauth.common.domain.PriceInteractor;
import jp.co.soramitsu.oauth.feature.session.domain.UserSessionRepository;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class VerificationRejectedViewModel_Factory implements Factory<VerificationRejectedViewModel> {
  private final Provider<MainRouter> mainRouterProvider;

  private final Provider<UserSessionRepository> userSessionRepositoryProvider;

  private final Provider<KycRepository> kycRepositoryProvider;

  private final Provider<SetActivityResult> setActivityResultProvider;

  private final Provider<PriceInteractor> priceInteractorProvider;

  private final Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider;

  public VerificationRejectedViewModel_Factory(Provider<MainRouter> mainRouterProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider,
      Provider<KycRepository> kycRepositoryProvider,
      Provider<SetActivityResult> setActivityResultProvider,
      Provider<PriceInteractor> priceInteractorProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    this.mainRouterProvider = mainRouterProvider;
    this.userSessionRepositoryProvider = userSessionRepositoryProvider;
    this.kycRepositoryProvider = kycRepositoryProvider;
    this.setActivityResultProvider = setActivityResultProvider;
    this.priceInteractorProvider = priceInteractorProvider;
    this.pwoAuthClientProxyProvider = pwoAuthClientProxyProvider;
  }

  @Override
  public VerificationRejectedViewModel get() {
    return newInstance(mainRouterProvider.get(), userSessionRepositoryProvider.get(), kycRepositoryProvider.get(), setActivityResultProvider.get(), priceInteractorProvider.get(), pwoAuthClientProxyProvider.get());
  }

  public static VerificationRejectedViewModel_Factory create(
      javax.inject.Provider<MainRouter> mainRouterProvider,
      javax.inject.Provider<UserSessionRepository> userSessionRepositoryProvider,
      javax.inject.Provider<KycRepository> kycRepositoryProvider,
      javax.inject.Provider<SetActivityResult> setActivityResultProvider,
      javax.inject.Provider<PriceInteractor> priceInteractorProvider,
      javax.inject.Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    return new VerificationRejectedViewModel_Factory(Providers.asDaggerProvider(mainRouterProvider), Providers.asDaggerProvider(userSessionRepositoryProvider), Providers.asDaggerProvider(kycRepositoryProvider), Providers.asDaggerProvider(setActivityResultProvider), Providers.asDaggerProvider(priceInteractorProvider), Providers.asDaggerProvider(pwoAuthClientProxyProvider));
  }

  public static VerificationRejectedViewModel_Factory create(
      Provider<MainRouter> mainRouterProvider,
      Provider<UserSessionRepository> userSessionRepositoryProvider,
      Provider<KycRepository> kycRepositoryProvider,
      Provider<SetActivityResult> setActivityResultProvider,
      Provider<PriceInteractor> priceInteractorProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider) {
    return new VerificationRejectedViewModel_Factory(mainRouterProvider, userSessionRepositoryProvider, kycRepositoryProvider, setActivityResultProvider, priceInteractorProvider, pwoAuthClientProxyProvider);
  }

  public static VerificationRejectedViewModel newInstance(MainRouter mainRouter,
      UserSessionRepository userSessionRepository, KycRepository kycRepository,
      SetActivityResult setActivityResult, PriceInteractor priceInteractor,
      PWOAuthClientProxy pwoAuthClientProxy) {
    return new VerificationRejectedViewModel(mainRouter, userSessionRepository, kycRepository, setActivityResult, priceInteractor, pwoAuthClientProxy);
  }
}
