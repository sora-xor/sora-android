package jp.co.soramitsu.oauth.common.di;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.sdk.InMemoryRepo;
import jp.co.soramitsu.oauth.common.domain.KycRepository;
import jp.co.soramitsu.oauth.common.domain.PriceInteractor;
import jp.co.soramitsu.oauth.feature.session.domain.UserSessionRepository;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class CommonModule_ProvidePriceInteractorFactory implements Factory<PriceInteractor> {
  private final CommonModule module;

  private final Provider<UserSessionRepository> userSessionRepositoryProvider;

  private final Provider<InMemoryRepo> inMemoryRepoProvider;

  private final Provider<KycRepository> kycRepositoryProvider;

  public CommonModule_ProvidePriceInteractorFactory(CommonModule module,
      Provider<UserSessionRepository> userSessionRepositoryProvider,
      Provider<InMemoryRepo> inMemoryRepoProvider, Provider<KycRepository> kycRepositoryProvider) {
    this.module = module;
    this.userSessionRepositoryProvider = userSessionRepositoryProvider;
    this.inMemoryRepoProvider = inMemoryRepoProvider;
    this.kycRepositoryProvider = kycRepositoryProvider;
  }

  @Override
  public PriceInteractor get() {
    return providePriceInteractor(module, userSessionRepositoryProvider.get(), inMemoryRepoProvider.get(), kycRepositoryProvider.get());
  }

  public static CommonModule_ProvidePriceInteractorFactory create(CommonModule module,
      javax.inject.Provider<UserSessionRepository> userSessionRepositoryProvider,
      javax.inject.Provider<InMemoryRepo> inMemoryRepoProvider,
      javax.inject.Provider<KycRepository> kycRepositoryProvider) {
    return new CommonModule_ProvidePriceInteractorFactory(module, Providers.asDaggerProvider(userSessionRepositoryProvider), Providers.asDaggerProvider(inMemoryRepoProvider), Providers.asDaggerProvider(kycRepositoryProvider));
  }

  public static CommonModule_ProvidePriceInteractorFactory create(CommonModule module,
      Provider<UserSessionRepository> userSessionRepositoryProvider,
      Provider<InMemoryRepo> inMemoryRepoProvider, Provider<KycRepository> kycRepositoryProvider) {
    return new CommonModule_ProvidePriceInteractorFactory(module, userSessionRepositoryProvider, inMemoryRepoProvider, kycRepositoryProvider);
  }

  public static PriceInteractor providePriceInteractor(CommonModule instance,
      UserSessionRepository userSessionRepository, InMemoryRepo inMemoryRepo,
      KycRepository kycRepository) {
    return Preconditions.checkNotNullFromProvides(instance.providePriceInteractor(userSessionRepository, inMemoryRepo, kycRepository));
  }
}
