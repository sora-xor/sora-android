package jp.co.soramitsu.oauth.clients;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Provider;
import dagger.internal.Providers;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import jp.co.soramitsu.oauth.base.sdk.InMemoryRepo;
import jp.co.soramitsu.oauth.common.domain.KycRepository;
import jp.co.soramitsu.oauth.common.domain.PWOAuthClientProxy;
import jp.co.soramitsu.oauth.feature.AccessTokenValidator;
import jp.co.soramitsu.oauth.feature.session.domain.UserSessionRepository;
import jp.co.soramitsu.oauth.network.SoraCardNetworkClient;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava",
    "cast",
    "deprecation",
    "nullness:initialization.field.uninitialized"
})
public final class ClientsFacade_Factory implements Factory<ClientsFacade> {
  private final Provider<UserSessionRepository> userSessionRepositoryProvider;

  private final Provider<SoraCardNetworkClient> apiClientProvider;

  private final Provider<KycRepository> kycRepositoryProvider;

  private final Provider<AccessTokenValidator> tokenValidatorProvider;

  private final Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider;

  private final Provider<InMemoryRepo> inMemoryRepoProvider;

  public ClientsFacade_Factory(Provider<UserSessionRepository> userSessionRepositoryProvider,
      Provider<SoraCardNetworkClient> apiClientProvider,
      Provider<KycRepository> kycRepositoryProvider,
      Provider<AccessTokenValidator> tokenValidatorProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider,
      Provider<InMemoryRepo> inMemoryRepoProvider) {
    this.userSessionRepositoryProvider = userSessionRepositoryProvider;
    this.apiClientProvider = apiClientProvider;
    this.kycRepositoryProvider = kycRepositoryProvider;
    this.tokenValidatorProvider = tokenValidatorProvider;
    this.pwoAuthClientProxyProvider = pwoAuthClientProxyProvider;
    this.inMemoryRepoProvider = inMemoryRepoProvider;
  }

  @Override
  public ClientsFacade get() {
    return newInstance(userSessionRepositoryProvider.get(), apiClientProvider.get(), kycRepositoryProvider.get(), tokenValidatorProvider.get(), pwoAuthClientProxyProvider.get(), inMemoryRepoProvider.get());
  }

  public static ClientsFacade_Factory create(
      javax.inject.Provider<UserSessionRepository> userSessionRepositoryProvider,
      javax.inject.Provider<SoraCardNetworkClient> apiClientProvider,
      javax.inject.Provider<KycRepository> kycRepositoryProvider,
      javax.inject.Provider<AccessTokenValidator> tokenValidatorProvider,
      javax.inject.Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider,
      javax.inject.Provider<InMemoryRepo> inMemoryRepoProvider) {
    return new ClientsFacade_Factory(Providers.asDaggerProvider(userSessionRepositoryProvider), Providers.asDaggerProvider(apiClientProvider), Providers.asDaggerProvider(kycRepositoryProvider), Providers.asDaggerProvider(tokenValidatorProvider), Providers.asDaggerProvider(pwoAuthClientProxyProvider), Providers.asDaggerProvider(inMemoryRepoProvider));
  }

  public static ClientsFacade_Factory create(
      Provider<UserSessionRepository> userSessionRepositoryProvider,
      Provider<SoraCardNetworkClient> apiClientProvider,
      Provider<KycRepository> kycRepositoryProvider,
      Provider<AccessTokenValidator> tokenValidatorProvider,
      Provider<PWOAuthClientProxy> pwoAuthClientProxyProvider,
      Provider<InMemoryRepo> inMemoryRepoProvider) {
    return new ClientsFacade_Factory(userSessionRepositoryProvider, apiClientProvider, kycRepositoryProvider, tokenValidatorProvider, pwoAuthClientProxyProvider, inMemoryRepoProvider);
  }

  public static ClientsFacade newInstance(UserSessionRepository userSessionRepository,
      SoraCardNetworkClient apiClient, KycRepository kycRepository,
      AccessTokenValidator tokenValidator, PWOAuthClientProxy pwoAuthClientProxy,
      InMemoryRepo inMemoryRepo) {
    return new ClientsFacade(userSessionRepository, apiClient, kycRepository, tokenValidator, pwoAuthClientProxy, inMemoryRepo);
  }
}
