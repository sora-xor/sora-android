package jp.co.soramitsu.xsubstrate.exceptions

class JunctionTypeException : Exception()
