package jp.co.soramitsu.xsubstrate.runtime.definitions.types.generics

import jp.co.soramitsu.xsubstrate.runtime.definitions.types.primitives.DynamicByteArray

val Bytes = DynamicByteArray("Bytes")
