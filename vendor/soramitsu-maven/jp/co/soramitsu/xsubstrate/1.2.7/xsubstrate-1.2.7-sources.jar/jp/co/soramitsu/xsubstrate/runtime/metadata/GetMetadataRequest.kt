package jp.co.soramitsu.xsubstrate.runtime.metadata

import jp.co.soramitsu.xsubstrate.wsrpc.request.runtime.RuntimeRequest

object GetMetadataRequest : RuntimeRequest("state_getMetadata", listOf())
