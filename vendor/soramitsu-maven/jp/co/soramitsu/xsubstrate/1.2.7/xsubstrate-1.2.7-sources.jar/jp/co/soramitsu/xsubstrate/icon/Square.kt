package jp.co.soramitsu.xsubstrate.icon

data class Square(
    val x: Double,
    val y: Double,
    val colorString: String,
    val sideSize: Double,
    val rotation: Float,
)
