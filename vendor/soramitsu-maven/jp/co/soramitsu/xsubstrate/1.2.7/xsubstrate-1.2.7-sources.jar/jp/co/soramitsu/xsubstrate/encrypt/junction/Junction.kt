package jp.co.soramitsu.xsubstrate.encrypt.junction

data class Junction(val type: JunctionType, val chaincode: ByteArray)
