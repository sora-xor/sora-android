package jp.co.soramitsu.xsubstrate.wsrpc.exception

import java.lang.Exception

class RpcException(message: String?) : Exception(message)
