package jp.co.soramitsu.xsubstrate.encrypt.junction

enum class JunctionType {
    SOFT,
    HARD,
}
