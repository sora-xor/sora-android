package jp.co.soramitsu.xsubstrate.icon

data class Scheme(
    val name: String,
    val frequency: Int,
    val colors: Array<Int>,
)
