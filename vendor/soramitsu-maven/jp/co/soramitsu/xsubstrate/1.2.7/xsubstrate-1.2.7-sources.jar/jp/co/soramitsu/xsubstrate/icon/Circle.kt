package jp.co.soramitsu.xsubstrate.icon

data class Circle(
    val x: Double,
    val y: Double,
    val colorString: String,
    val radius: Int,
)
