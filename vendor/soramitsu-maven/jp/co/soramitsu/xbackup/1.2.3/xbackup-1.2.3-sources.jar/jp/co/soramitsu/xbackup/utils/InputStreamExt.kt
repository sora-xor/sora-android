package jp.co.soramitsu.xbackup.utils

import java.io.InputStream

fun InputStream.readToString(): String {
    return this.bufferedReader().use { it.readText() }
}
