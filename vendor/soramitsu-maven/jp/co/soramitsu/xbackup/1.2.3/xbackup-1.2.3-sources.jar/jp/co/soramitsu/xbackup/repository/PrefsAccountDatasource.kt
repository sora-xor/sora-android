package jp.co.soramitsu.xbackup.repository

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import jp.co.soramitsu.xbackup.domain.AccountDatasource
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

class PrefsAccountDatasource(context: Context) : AccountDatasource {
    private val Context.dataStorePrefs by preferencesDataStore(
        name = PREFS_NAME,
    )

    private val datastore = context.dataStorePrefs

    override suspend fun saveFileId(
        address: String,
        fileId: String,
    ) {
        datastore.edit {
            it[stringPreferencesKey(address)] = fileId
        }
    }

    override suspend fun getFileId(address: String): String {
        return datastore.data.map {
            it[stringPreferencesKey(address)] ?: ""
        }.first()
    }

    override suspend fun removeFileId(address: String) {
        datastore.edit {
            it.remove(stringPreferencesKey(address))
        }
    }

    override suspend fun removeAllFields() {
        datastore.edit {
            it.clear()
        }
    }

    companion object {
        private const val PREFS_NAME = "backup_preferences"
    }
}
