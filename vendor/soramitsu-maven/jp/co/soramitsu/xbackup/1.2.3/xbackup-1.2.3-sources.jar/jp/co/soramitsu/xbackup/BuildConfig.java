/**
 * Automatically generated file. DO NOT MODIFY
 */
package jp.co.soramitsu.xbackup;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "jp.co.soramitsu.xbackup";
  public static final String BUILD_TYPE = "release";
}
