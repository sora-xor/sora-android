package jp.co.soramitsu.xbackup.domain

interface AccountDatasource {
    suspend fun saveFileId(
        address: String,
        fileId: String,
    )

    suspend fun getFileId(address: String): String

    suspend fun removeFileId(address: String)

    suspend fun removeAllFields()
}
