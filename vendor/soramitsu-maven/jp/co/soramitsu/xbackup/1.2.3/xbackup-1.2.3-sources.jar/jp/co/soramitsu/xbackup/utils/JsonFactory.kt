package jp.co.soramitsu.xbackup.utils

import kotlinx.serialization.json.Json

object JsonFactory {
    fun create(): Json {
        return Json {
            prettyPrint = false
            isLenient = true
            ignoreUnknownKeys = true
            coerceInputValues = true
            encodeDefaults = true
        }
    }
}
