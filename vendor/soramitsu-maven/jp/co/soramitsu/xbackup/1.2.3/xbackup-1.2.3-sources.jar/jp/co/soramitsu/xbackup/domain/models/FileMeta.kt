package jp.co.soramitsu.xbackup.domain.models

data class FileMeta(
    val fileName: String,
    val description: String,
    val fileId: String,
)
