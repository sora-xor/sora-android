package jp.co.soramitsu.xbackup.repository

import android.content.Context
import android.content.Intent
import androidx.activity.result.ActivityResultLauncher
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.googleapis.extensions.android.gms.auth.UserRecoverableAuthIOException
import com.google.api.client.googleapis.json.GoogleJsonResponseException
import com.google.api.client.http.FileContent
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File
import java.util.Collections
import jp.co.soramitsu.xbackup.domain.Storage
import jp.co.soramitsu.xbackup.domain.exceptions.AuthConsentException
import jp.co.soramitsu.xbackup.domain.exceptions.FileNotFoundException
import jp.co.soramitsu.xbackup.domain.exceptions.InsufficientFilePermissions
import jp.co.soramitsu.xbackup.domain.exceptions.StorageQuotaExceeded
import jp.co.soramitsu.xbackup.domain.exceptions.UnauthorizedException
import jp.co.soramitsu.xbackup.domain.models.FileMeta
import jp.co.soramitsu.xbackup.utils.readToString
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext

internal class GoogleDriveStorage(tokenId: String) : Storage {
    private val signInOptions: GoogleSignInOptions =
        GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(tokenId)
            .requestEmail()
            .requestScopes(Scope(DriveScopes.DRIVE_APPDATA))
            .build()

    private val backupFolderName = "backupFolder"
    private val appDataFolder = "appDataFolder"
    private val storageQuotaErrorReason = "storageQuotaExceeded"
    private val insufficientFilePermissionsReason = "insufficientFilePermissions"
    private val notFoundCode = 404
    private val forbiddenCode = 403

    @Volatile
    private var drive: Drive? = null

    override suspend fun saveFile(
        context: Context,
        name: String,
        description: String,
        file: java.io.File,
    ): String {
        return withContext(Dispatchers.IO) {
            silentSignInAndCheckAuthorization(context)

            try {
                getGoogleDrive(context).let { drive ->
                    val folderId = getParentFolder(drive)

                    val metadata: File =
                        File()
                            .setParents(Collections.singletonList(folderId))
                            .setMimeType("text/json")
                            .setName(name)
                            .setDescription(description)

                    val mediaContent = FileContent("text/json", file)

                    return@withContext drive.files()
                        .create(metadata, mediaContent)
                        .setFields("id, description, name")
                        .execute()
                        .id
                }
            } catch (e: UserRecoverableAuthIOException) {
                throw AuthConsentException(e, e.intent)
            } catch (e1: GoogleJsonResponseException) {
                throw if (e1.statusCode == forbiddenCode) {
                    e1.details.errors.firstOrNull { it.reason == storageQuotaErrorReason }
                        ?.let {
                            StorageQuotaExceeded(e1)
                        } ?: e1
                } else {
                    e1
                }
            }
        }
    }

    override suspend fun signIn(
        context: Context,
        activityResultLauncher: ActivityResultLauncher<Intent>,
    ): Boolean {
        return suspendCancellableCoroutine { cancellableContinuation ->
            if (isAuthorized(context)) {
                cancellableContinuation.resume(true)
            } else {
                val client = GoogleSignIn.getClient(context, signInOptions)

                client.silentSignIn().addOnCanceledListener {
                    activityResultLauncher.launch(client.signInIntent)
                    cancellableContinuation.cancel()
                }.addOnCompleteListener {
                    if (it.isSuccessful) {
                        cancellableContinuation.resume(true)
                    } else {
                        val intent = client.signInIntent
                        activityResultLauncher.launch(intent)
                        cancellableContinuation.resume(false)
                    }
                }
            }
        }
    }

    override suspend fun getFileContent(
        context: Context,
        fileId: String,
    ): String {
        return withContext(Dispatchers.IO) {
            silentSignInAndCheckAuthorization(context)

            try {
                getGoogleDrive(context)
                    .files()
                    .get(fileId)
                    ?.executeMediaAsInputStream()
                    ?.readToString() ?: ""
            } catch (e: UserRecoverableAuthIOException) {
                throw AuthConsentException(e, e.intent)
            }
        }
    }

    override suspend fun getListOfFileHeads(context: Context): List<FileMeta> {
        return withContext(Dispatchers.IO) {
            silentSignInAndCheckAuthorization(context)

            try {
                val drive = getGoogleDrive(context)

                val folderId = getParentFolder(drive)

                drive.files()
                    .list()
                    .setFields("files(id, name, description)")
                    .setSpaces(appDataFolder)
                    .setQ("'$folderId' in parents")
                    .execute()
                    .files.map {
                        FileMeta(
                            fileName = it.name,
                            description = it.description.orEmpty(),
                            fileId = it.id,
                        )
                    }
            } catch (e: UserRecoverableAuthIOException) {
                throw AuthConsentException(e, e.intent)
            }
        }
    }

    @Throws(AuthConsentException::class)
    override suspend fun getWebListOfFileHeads(context: Context): List<FileMeta> {
        return withContext(Dispatchers.IO) {
            silentSignInAndCheckAuthorization(context)

            try {
                val drive = getGoogleDrive(context)

                drive.files()
                    .list()
                    .setFields("files(id, name, description)")
                    .setSpaces(appDataFolder)
                    .setQ("'$appDataFolder' in parents and mimeType != 'application/vnd.google-apps.folder'")
                    .execute()
                    .files.map {
                        FileMeta(
                            fileName = it.name,
                            description = it.description.orEmpty(),
                            fileId = it.id,
                        )
                    }
            } catch (e: UserRecoverableAuthIOException) {
                throw AuthConsentException(e, e.intent)
            }
        }
    }

    override suspend fun deleteFile(
        context: Context,
        fileId: String,
    ) {
        withContext(Dispatchers.IO) {
            try {
                silentSignInAndCheckAuthorization(context)

                getGoogleDrive(context).files()?.delete(fileId)?.execute()
            } catch (e: GoogleJsonResponseException) {
                throw if (e.statusCode == notFoundCode) {
                    FileNotFoundException(e)
                } else {
                    e
                }
            } catch (e: UserRecoverableAuthIOException) {
                throw AuthConsentException(e, e.intent)
            }
        }
    }

    override suspend fun deleteAllFiles(context: Context) {
        withContext(Dispatchers.IO) {
            silentSignInAndCheckAuthorization(context)

            try {
                val drive = getGoogleDrive(context)
                val folderId = getParentFolder(drive)
                drive.files()
                    .delete(folderId)
                    .execute()
            } catch (e: UserRecoverableAuthIOException) {
                throw AuthConsentException(e, e.intent)
            }
        }
    }

    override suspend fun logout(context: Context) {
        return suspendCancellableCoroutine { cancellableContinuation ->
            val client = GoogleSignIn.getClient(context, signInOptions)
            client.signOut().addOnCanceledListener {
                cancellableContinuation.cancel()
            }.addOnCompleteListener {
                drive = null
                cancellableContinuation.resume(Unit)
            }
        }
    }

    private fun getParentFolder(drive: Drive): String {
        val result =
            drive.files()
                .list()
                .setFields("files(id)")
                .setSpaces(appDataFolder)
                .setQ("name = '$backupFolderName'")
                .execute()

        val res =
            if (!result.files.isNullOrEmpty()) {
                result.files.first().id
            } else {
                val metadata: File =
                    File()
                        .setParents(Collections.singletonList(appDataFolder))
                        .setMimeType("application/vnd.google-apps.folder")
                        .setName(backupFolderName)

                try {
                    drive.files()
                        .create(metadata)
                        .setFields("id")
                        .execute()
                        .id
                } catch (e: GoogleJsonResponseException) {
                    throw handleCreatingParentFolderException(e)
                }
            }

        return res
    }

    private fun handleCreatingParentFolderException(e: GoogleJsonResponseException): Throwable {
        return if (
            e.statusCode == forbiddenCode && e.details.errors.firstOrNull {
                it.reason == insufficientFilePermissionsReason
            } != null
        ) {
            InsufficientFilePermissions(e)
        } else {
            e
        }
    }

    private fun getGoogleDrive(context: Context): Drive {
        return drive ?: synchronized(this) {
            drive ?: buildGoogleDrive(context).also {
                drive = it
            }
        }
    }

    private fun buildGoogleDrive(context: Context): Drive {
        val credential: GoogleAccountCredential =
            GoogleAccountCredential.usingOAuth2(
                context,
                Collections.singleton(DriveScopes.DRIVE_APPDATA),
            )
        credential.selectedAccount = GoogleSignIn.getLastSignedInAccount(context)?.account
        return Drive.Builder(
            NetHttpTransport.Builder().build(),
            GsonFactory(),
            credential,
        ).build()
    }

    private fun isAuthorized(context: Context): Boolean {
        val lastSigned = GoogleSignIn.getLastSignedInAccount(context)
        return lastSigned != null && !lastSigned.isExpired
    }

    private suspend fun silentSignInAndCheckAuthorization(context: Context) {
        suspendCancellableCoroutine { continuation ->
            if (isAuthorized(context)) {
                continuation.resume(Unit)
            } else {
                silentSignin(context, continuation)
            }
        }
    }

    private fun silentSignin(
        context: Context,
        continuation: CancellableContinuation<Unit>,
    ) {
        GoogleSignIn.getClient(context, signInOptions).silentSignIn()
            .addOnCanceledListener {
                continuation.cancel()
            }
            .addOnCompleteListener {
                if (it.isSuccessful) {
                    continuation.resume(Unit)
                } else {
                    continuation.resumeWithException(UnauthorizedException())
                }
            }
    }
}
