package jp.co.soramitsu.xbackup.domain

import java.io.File
import jp.co.soramitsu.xbackup.domain.exceptions.DecodingException
import jp.co.soramitsu.xbackup.domain.models.EncryptedBackupAccount
import jp.co.soramitsu.xbackup.utils.JsonFactory
import kotlinx.serialization.SerializationException
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

internal class AccountJsonMapper(private val json: Json = JsonFactory.create()) {
    fun mapEncryptedAccountToJsonFile(
        filePath: String,
        encryptedAccount: EncryptedBackupAccount,
    ): File {
        val jsonString = json.encodeToString(encryptedAccount)
        val file = File(filePath + encryptedAccount.address + ".json")
        file.writeText(jsonString)

        return file
    }

    fun mapJsonStringToEncryptedAccount(jsonString: String): EncryptedBackupAccount {
        return try {
            json.decodeFromString(jsonString)
        } catch (e: SerializationException) {
            throw DecodingException(e)
        }
    }
}
