package jp.co.soramitsu.xbackup.domain.exceptions

import android.content.Intent
import com.google.api.client.googleapis.extensions.android.gms.auth.UserRecoverableAuthIOException

class UnauthorizedException(e: Exception? = null) : Throwable(e)

class DecryptionException(e: Exception? = null) : Throwable(e)

class DecodingException(e: Exception? = null) : Throwable(e)

class AuthConsentException(e: UserRecoverableAuthIOException, val intent: Intent = e.intent) : Throwable(e)

class FileNotFoundException(e: Exception) : Throwable(e)

class StorageQuotaExceeded(e: Exception) : Throwable(e)

class InsufficientFilePermissions(e: Exception) : Throwable(e)
