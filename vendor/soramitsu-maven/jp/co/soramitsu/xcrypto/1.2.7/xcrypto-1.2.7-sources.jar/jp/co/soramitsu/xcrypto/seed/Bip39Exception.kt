package jp.co.soramitsu.xcrypto.seed

class Bip39Exception : Exception()
