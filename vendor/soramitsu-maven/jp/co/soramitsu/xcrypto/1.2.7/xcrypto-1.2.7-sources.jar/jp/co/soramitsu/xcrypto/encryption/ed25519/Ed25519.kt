package jp.co.soramitsu.xcrypto.encryption.ed25519

import java.security.KeyFactory
import java.security.Security
import java.security.Signature
import jp.co.soramitsu.xcrypto.encryption.KeypairWithSeed
import net.i2p.crypto.eddsa.EdDSAEngine
import net.i2p.crypto.eddsa.EdDSAKey
import net.i2p.crypto.eddsa.EdDSAPrivateKey
import net.i2p.crypto.eddsa.EdDSAPublicKey
import net.i2p.crypto.eddsa.EdDSASecurityProvider
import net.i2p.crypto.eddsa.spec.EdDSANamedCurveTable
import net.i2p.crypto.eddsa.spec.EdDSAParameterSpec
import net.i2p.crypto.eddsa.spec.EdDSAPrivateKeySpec
import net.i2p.crypto.eddsa.spec.EdDSAPublicKeySpec

object Ed25519 {

    private const val ED25519_PRIVATE_KEY_PREFIX = "302e020100300506032b657004220420"
    private const val ED25519_PUBLIC_KEY_PREFIX = "302a300506032b6570032100"

    init {
        Security.addProvider(EdDSASecurityProvider())
    }

    fun deriveFromSeed(seed: ByteArray): KeypairWithSeed {
        val keyFac = KeyFactory.getInstance(EdDSAKey.KEY_ALGORITHM, "EdDSA")
        val spec = EdDSANamedCurveTable.getByName(EdDSANamedCurveTable.ED_25519)
        val privKeySpec = EdDSAPrivateKeySpec(seed, spec)
        val private = keyFac.generatePrivate(privKeySpec).encoded
        val publicKeySpec = EdDSAPublicKeySpec(privKeySpec.a, spec)
        val public = keyFac.generatePublic(publicKeySpec).encoded

        return KeypairWithSeed(
            seed = seed,
            private.copyOfRange(
                ED25519_PRIVATE_KEY_PREFIX.length / 2,
                private.size
            ),
            public.copyOfRange(ED25519_PUBLIC_KEY_PREFIX.length / 2, public.size)
        )
    }

    fun sign(message: ByteArray, privateKey: ByteArray): ByteArray {
        val spec: EdDSAParameterSpec = EdDSANamedCurveTable.getByName(EdDSANamedCurveTable.ED_25519)
        val sgr: Signature = Signature.getInstance(
            EdDSAEngine.SIGNATURE_ALGORITHM,
            EdDSASecurityProvider.PROVIDER_NAME
        )
        val privKeySpec = EdDSAPrivateKeySpec(privateKey, spec)
        val private = EdDSAPrivateKey(privKeySpec)
        sgr.initSign(private)
        sgr.update(message)

        return sgr.sign()
    }

    fun verify(
        message: ByteArray,
        signature: ByteArray,
        publicKey: ByteArray
    ): Boolean {
        val spec: EdDSAParameterSpec = EdDSANamedCurveTable.getByName(EdDSANamedCurveTable.ED_25519)
        val sgr: Signature = Signature.getInstance(
            EdDSAEngine.SIGNATURE_ALGORITHM,
            EdDSASecurityProvider.PROVIDER_NAME
        )

        val privKeySpec = EdDSAPublicKeySpec(publicKey, spec)
        val public = EdDSAPublicKey(privKeySpec)
        sgr.initVerify(public)
        sgr.update(message)

        return sgr.verify(signature)
    }
}
