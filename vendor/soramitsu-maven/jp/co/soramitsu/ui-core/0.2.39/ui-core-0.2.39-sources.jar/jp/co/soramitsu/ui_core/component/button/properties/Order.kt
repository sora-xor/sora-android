package jp.co.soramitsu.ui_core.component.button.properties

enum class Order {

    PRIMARY,
    SECONDARY,
    TERTIARY
}
