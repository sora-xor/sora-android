/*
 * Copyright 2026 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.ui.tooling.animation.search

import androidx.compose.ui.tooling.animation.ClockInfo
import androidx.compose.ui.tooling.animation.UnsupportedComposeAnimation
import androidx.compose.ui.tooling.animation.clock.NoopClock
import androidx.compose.ui.tooling.animation.states.NoopState

internal class UnsupportedSearchInfo(animation: Any, override val label: String) :
    SearchInfo<UnsupportedComposeAnimation, NoopClock> {
    override val animationObject: Any = animation

    override val initialState = NoopState
    override val targetState = NoopState

    override fun setTargetStateToCurrentAnimationValue() {}

    override fun setInitialStateToCurrentAnimationValue() {}

    override fun createAnimation(): UnsupportedComposeAnimation? {
        return UnsupportedComposeAnimation.create(label)
    }

    override fun createClock(
        animation: UnsupportedComposeAnimation,
        clockInfo: ClockInfo,
    ): NoopClock {
        return NoopClock(animation)
    }
}
